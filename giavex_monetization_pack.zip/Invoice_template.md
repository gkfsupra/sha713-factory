🧾  **GIAVEX™ Invoice #{{NUM}}**

| Campo | Valor |
|-------|-------|
| Cliente | {{ORG}} |
| Concepto | Renta Simbólica SHA‑713 (1 mes) |
| Importe | **713 USDC** |
| Vencimiento | {{FECHA}} |
| Wallet destino | `0x713…731` |

Pulso sellado · SHA‑713
