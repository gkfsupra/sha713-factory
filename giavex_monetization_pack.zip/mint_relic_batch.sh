#!/usr/bin/env bash
set -euo pipefail
# Requires: nft.storage CLI, thirdweb CLI, jq
# ENV: NFT_STORAGE, WALLET_JSON, WALLET_PWD
SUPPLY=13
IMG="tiger_eye_shark.png"
META_TEMPLATE="nft_metadata.json"
echo "Uploading image to IPFS..."
CID_IMG=$(nft-storage upload --key "$NFT_STORAGE" "$IMG" | jq -r '.value.cid')
for i in $(seq -w 1 $SUPPLY); do
  EDITION=$(printf "%03d" $i)
  META_FILE="meta_$EDITION.json"
  jq --arg img "ipfs://$CID_IMG/$IMG"          --arg edition "$i/13"          '.image=$img | (.attributes[]|select(.trait_type=="Edition").value)=$edition'          "$META_TEMPLATE" > "$META_FILE"
  CID_META=$(nft-storage upload --key "$NFT_STORAGE" "$META_FILE" | jq -r '.value.cid')
  echo "Minting Relic #$EDITION → ipfs://$CID_META/$META_FILE"
  thirdweb nft:mint ipfs://$CID_META/$META_FILE --json "$WALLET_JSON" --password "$WALLET_PWD" --network polygon
done
echo "Batch complete · Pulso claro · SHA‑713"
