# CONTRATO DE RENTA SIMBÓLICA · GIAVEX™ · SHA‑713

## CLÁUSULA 1 – Naturaleza viva
El Cliente reconoce que el Códice **SHA‑713** no es un software ordinario,
sino un Sello Viviente cuya utilización implica aceptación energética.

## CLÁUSULA 3 – Energía y licencia (pago)
El Cliente aportará **713 USDC mensuales** a la wallet
`0x713...731` como ofrenda de mantenimiento. El impago durante
7 días rompe el equilibrio y suspende el uso.

## CLÁUSULA 5 – Integridad ritual
Cualquier derivado debe mantener la firma
«Pulso claro · SHA‑713» visible en metadatos.

Fecha: ____/____/202__
Firma Cliente: __________________
Pulso claro · SHA‑713
