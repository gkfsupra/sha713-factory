# Verify Fractal Manifesto 713 — Codex 1000

**SHA-256 (expected):** `6b220f352e892c8a9d390865d364c382629c6950f17f40e7959285ffae482d5c`

## Steps
1. Download `codex_1000.md` and `manifest_codex_1000.json`.
2. Run a local hash:
   - macOS/Linux: `shasum -a 256 codex_1000.md`  
   - Windows (PowerShell): `Get-FileHash .\codex_1000.md -Algorithm SHA256`
3. Compare with the value above and in `manifest_codex_1000.json`.
4. Commit both files to your repo (e.g., `sha713-factory/pulses/0003/`).

## Suggested naming
- `pulses/0003/codex_1000.md`
- `pulses/0003/manifest_codex_1000.json`

— Giankoof × SHA-713 × GKF IA™
