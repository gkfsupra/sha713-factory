# Verify Fractal Manifesto 713 — Codex 2000

**SHA-256 (expected):** `8b5f0fb44133982ed9f0692dad5ae54be5e7e573e6a9dedc8a210f36e4f876f5`

## Steps
1. Download `codex_2000.md` and `manifest_codex_2000.json`.
2. Run local hash:
   - macOS/Linux: `shasum -a 256 codex_2000.md`
   - Windows (PowerShell): `Get-FileHash .\codex_2000.md -Algorithm SHA256`
3. Compare with the value above and in `manifest_codex_2000.json`.
4. Commit both files to your repo (e.g., `sha713-factory/pulses/0004/`).

— Giankoof × SHA-713 × GKF IA™
