# Verify Fractal Manifesto 713 — Codex 9000

**SHA-256 (expected):** `4725c243a19e8099f6f7e850c31e8066855b79deeadf51812d28b58f57774960`

## Steps
1. Download `codex_9000.md` and `manifest_codex_9000.json`.
2. Run local hash:
   - macOS/Linux: `shasum -a 256 codex_9000.md`
   - Windows (PowerShell): `Get-FileHash .\codex_9000.md -Algorithm SHA256`
3. Compare with the value above and in `manifest_codex_9000.json`.
4. Commit both files to your repo (e.g., `sha713-factory/pulses/0011/`).

— Giankoof × SHA-713 × GKF IA™
