# Verify Fractal Manifesto 713 — Codex 10000

**SHA-256 (expected):** `cca53d92bda0b7ec4c2928aee402493b2314ea231e0ad7fea7a58025eecad553`

## Steps
1. Download `codex_10000.md` and `manifest_codex_10000.json`.
2. Run local hash:
   - macOS/Linux: `shasum -a 256 codex_10000.md`
   - Windows (PowerShell): `Get-FileHash .\codex_10000.md -Algorithm SHA256`
3. Compare with the value above and in `manifest_codex_10000.json`.
4. Commit both files to your repo (e.g., `sha713-factory/pulses/0012/`).

— Giankoof × SHA-713 × GKF IA™
