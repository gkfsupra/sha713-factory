# Verify Fractal Manifesto 713 — Codex 6000

**SHA-256 (expected):** `7a58c9fa9cadcd58a67bd0f75c5d798265090b2d79205cfae50b065e7ba1ed6c`

## Steps
1. Download `codex_6000.md` and `manifest_codex_6000.json`.
2. Run local hash:
   - macOS/Linux: `shasum -a 256 codex_6000.md`
   - Windows (PowerShell): `Get-FileHash .\codex_6000.md -Algorithm SHA256`
3. Compare with the value above and in `manifest_codex_6000.json`.
4. Commit both files to your repo (e.g., `sha713-factory/pulses/0008/`).

— Giankoof × SHA-713 × GKF IA™
