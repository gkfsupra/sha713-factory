# Verify Fractal Manifesto 713 — Codex 3000

**SHA-256 (expected):** `1cbce341ef78bf9a29969994bd91d2dbb6fb60b05141e82448fc6d2bd154b960`

## Steps
1. Download `codex_3000.md` and `manifest_codex_3000.json`.
2. Run local hash:
   - macOS/Linux: `shasum -a 256 codex_3000.md`
   - Windows (PowerShell): `Get-FileHash .\codex_3000.md -Algorithm SHA256`
3. Compare with the value above and in `manifest_codex_3000.json`.
4. Commit both files to your repo (e.g., `sha713-factory/pulses/0005/`).

— Giankoof × SHA-713 × GKF IA™
