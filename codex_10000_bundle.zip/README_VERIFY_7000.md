# Verify Fractal Manifesto 713 — Codex 7000

**SHA-256 (expected):** `f2055192d6ffa0f57f35ee8a07956fbba8af984c978e465303dd43263062e82b`

## Steps
1. Download `codex_7000.md` and `manifest_codex_7000.json`.
2. Run local hash:
   - macOS/Linux: `shasum -a 256 codex_7000.md`
   - Windows (PowerShell): `Get-FileHash .\codex_7000.md -Algorithm SHA256`
3. Compare with the value above and in `manifest_codex_7000.json`.
4. Commit both files to your repo (e.g., `sha713-factory/pulses/0009/`).

— Giankoof × SHA-713 × GKF IA™
