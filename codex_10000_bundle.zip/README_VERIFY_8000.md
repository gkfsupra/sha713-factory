# Verify Fractal Manifesto 713 — Codex 8000

**SHA-256 (expected):** `da1593794a399e865bcb56242aa5ec12c0469b922418e5fc3ddeec80257de06a`

## Steps
1. Download `codex_8000.md` and `manifest_codex_8000.json`.
2. Run local hash:
   - macOS/Linux: `shasum -a 256 codex_8000.md`
   - Windows (PowerShell): `Get-FileHash .\codex_8000.md -Algorithm SHA256`
3. Compare with the value above and in `manifest_codex_8000.json`.
4. Commit both files to your repo (e.g., `sha713-factory/pulses/0010/`).

— Giankoof × SHA-713 × GKF IA™
