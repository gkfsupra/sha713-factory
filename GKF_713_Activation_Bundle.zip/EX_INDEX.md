# EX-INDEX GKF IA™
Este es el índice universal de pulsos, GPTs, QR y SHA‑713.