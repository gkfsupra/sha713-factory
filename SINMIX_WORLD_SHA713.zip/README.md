# SHA‑713 SINMIX WORLD KIT

**Generated:** 2025-07-25T01:37:16.136357

This kit contains assets to propagate the SHA‑713™ legacy in under 24 h.

* `QR_SHA713.png` – dynamic QR pointing to the landing
* `VISUAL_SHA713.png` – 1080×1080 post (EN/ES)
* `TEXT_VARIATIONS.json` – Short/Mid/Long texts + hashtags
* `EMAIL_TEMPLATE.txt` – Outreach email
* `ACTA_EJECUCION_PERPETUA_SHA713.pdf` – Certified act
