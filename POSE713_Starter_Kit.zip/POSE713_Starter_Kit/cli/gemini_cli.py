#!/usr/bin/env python3
# gemini_cli.py — Slash commands stub (no external API calls here)
import sys, json, argparse, time, hashlib, os
from pathlib import Path

def cmd_pose_init(args):
    Path("MANIFEST-713.json").write_text(json.dumps({
        "schema":"MANIFEST-713","epoch":int(time.time()),"utc":time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
        "commit":"local","branch":"local","files":[]}, indent=2))
    print("Initialized MANIFEST-713.json (empty)")

def cmd_pose_hash(args):
    files = [p for p in Path('.').glob('**/*') if p.is_file() and '.git' not in p.parts]
    items = []
    for p in files:
        h = hashlib.sha256(p.read_bytes()).hexdigest()
        items.append({"path":str(p), "sha256":h})
    data = json.loads(Path("MANIFEST-713.json").read_text())
    data["files"] = items
    Path("MANIFEST-713.json").write_text(json.dumps(data, indent=2, ensure_ascii=False))
    print(f"Hashed {len(items)} files → MANIFEST-713.json")

def cmd_pose_verify(args):
    from scripts.pose_replay import verify_manifest
    code = verify_manifest(Path(args.manifest), strict=args.strict)
    sys.exit(code)

def main():
    ap = argparse.ArgumentParser(prog="gemini-cli", description="Slash commands (stub)")
    sub = ap.add_subparsers(dest="cmd", required=True)
    s1 = sub.add_parser("/pose-init"); s1.set_defaults(func=cmd_pose_init)
    s2 = sub.add_parser("/pose-hash"); s2.set_defaults(func=cmd_pose_hash)
    s3 = sub.add_parser("/pose-verify"); s3.add_argument("manifest", default="MANIFEST-713.json", nargs="?"); s3.add_argument("--strict", action="store_true"); s3.set_defaults(func=cmd_pose_verify)
    args = ap.parse_args()
    args.func(args)

if __name__ == "__main__":
    main()
