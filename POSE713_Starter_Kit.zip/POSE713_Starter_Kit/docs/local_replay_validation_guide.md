# PoSE-713 — Guía de Validación Local (Replay)

**Objetivo**  
Verificar que los archivos del repo coinciden con las huellas del `MANIFEST-713.json` generado por CI.

## Requisitos
- Python 3.9+
- `scripts/pose_replay.py` (incluido)

## Pasos
```bash
# 1) Clona o actualiza el repositorio
git clone <tu_repo> && cd <tu_repo>

# 2) Descarga MANIFEST-713.json desde el job "PoSE-713" (artifact) o cópialo a la raíz

# 3) Ejecuta verificación
python scripts/pose_replay.py MANIFEST-713.json --strict
```

## Resultados
- `[OK] path` → archivo coincide con la huella.
- `[DIFF] path` → el archivo no coincide (posible modificación).
- `[MISS] path` → archivo ausente.

**Footer UO-713**: añade `UO-713 · YYYY-MM-DD · SHA-256:<hash8> · QR:<link>` al final de documentos PDF/MD/HTML.
