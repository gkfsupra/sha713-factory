#!/usr/bin/env python3
# pose_replay.py — Verify MANIFEST-713 against current working tree
import argparse, json, hashlib, os, sys, time
from pathlib import Path

def sha256_file(p: Path) -> str:
    h = hashlib.sha256()
    with p.open('rb') as fh:
        for chunk in iter(lambda: fh.read(65536), b''):
            h.update(chunk)
    return h.hexdigest()

def verify_manifest(manifest_path: Path, strict: bool=False) -> int:
    data = json.loads(manifest_path.read_text())
    errors = 0
    print(f"== MANIFEST: epoch={data.get('epoch')} utc={data.get('utc')} commit={data.get('commit')[:7]} branch={data.get('branch')}")
    for item in data.get('files', []):
        p = Path(item['path'])
        expect = item['sha256']
        if not p.exists():
            print(f"[MISS] {p} (missing)")
            errors += 1
            continue
        got = sha256_file(p)
        if got != expect:
            print(f"[DIFF] {p} sha256 mismatch")
            print(f"  expect: {expect}")
            print(f"  got   : {got}")
            errors += 1
        else:
            print(f"[OK]   {p}")
    if strict and errors:
        return 2
    return 0 if errors == 0 else 1

if __name__ == "__main__":
    ap = argparse.ArgumentParser(description="Verify MANIFEST-713 against files")
    ap.add_argument("manifest", type=Path, help="path to MANIFEST-713.json")
    ap.add_argument("--strict", action="store_true", help="exit non-zero on any mismatch")
    args = ap.parse_args()
    sys.exit(verify_manifest(args.manifest, strict=args.strict))
