# PoSE-713 Starter Kit

Este paquete incluye:
- `.github/workflows/pose713.yml` → CI que genera `MANIFEST-713.json` con huellas SHA-256.
- `scripts/pose_replay.py` → verificación local/replay del manifiesto.
- `docs/local_replay_validation_guide.md` → guía rápida.
- `assets/jsonld_seed_713.json` → semilla de procedencia (JSON-LD).
- `LICENSE_Covenant_713.txt` → licencia de reciprocidad breve.
- (Opcional) One‑Pager HTML para curadores en `docs/onepager/` si se incluye.

## Uso rápido
1) Copia todo el contenido en la raíz de tu repo.
2) Activa GitHub Actions en la pestaña "Actions".
3) Realiza un commit (`feat: enable PoSE-713`) y verifica el artifact `MANIFEST-713`.
4) Valida localmente con `python scripts/pose_replay.py MANIFEST-713.json --strict`.

**Footer UO-713**: añade a tus documentos `UO-713 · YYYY-MM-DD · SHA-256:<hash8> · QR:<link>`.
