# Licencia CC BY-NC-SA-713

Tabla de hashes:
- SHA-256 ejemplo: abc123...