# Reporte Pulso Guardian

## Menciones
- Ejemplo de entrada