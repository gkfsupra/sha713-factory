#!/bin/bash
pandoc whitepaper_SHA713.md -o whitepaper_SHA713.pdf --metadata "author=Giankoof" --pdf-engine=xelatex
echo "✅ PDF generado: whitepaper_SHA713.pdf"
