const Twitter = require('twitter-lite');
const client = new Twitter({bearer_token: process.env.TWITTER_TOKEN});

(async () => {
  const hash = require("fs").readFileSync("ipfs_hash.txt", "utf8").trim();
  await client.post('statuses/update', {
    status: `🜂 New SHA‑713 pulse pinned:\nhttps://ipfs.io/ipfs/${hash} #GKFIA #Giankoof #SHA713`
  });
})();
