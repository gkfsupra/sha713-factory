
"""
build_view_html.py — generate a static HTML viewer embedding the ledger contents.
Usage:
  python build_view_html.py sha713_demo_v2/ledger.db out/trace_view.html
"""
from __future__ import annotations
import sqlite3, json, sys
from pathlib import Path

TEMPLATE = """<!doctype html>
<html><head>
<meta charset="utf-8"/>
<title>SHA-713 Trace Viewer</title>
<meta name="viewport" content="width=device-width, initial-scale=1"/>
<style>
body{font-family:system-ui,Segoe UI,Arial,sans-serif;background:#0b1020;color:#eaeaea;margin:0;padding:24px;}
h1{font-size:24px;margin:0 0 8px}
small{opacity:.75}
.container{max-width:1100px;margin:0 auto}
.panel{background:#121a33;border:1px solid #1e2a55;border-radius:12px;padding:16px;margin:12px 0}
.row{display:flex;gap:12px;align-items:center;flex-wrap:wrap}
input,select{background:#0b1020;color:#eaeaea;border:1px solid #1e2a55;border-radius:8px;padding:8px 10px}
code{background:#0b1020;padding:4px 6px;border-radius:6px;border:1px solid #1e2a55}
.badge{padding:4px 8px;border-radius:16px;background:#0b1020;border:1px solid #1e2a55;margin-left:8px}
.item{padding:10px;border-bottom:1px solid #1e2a55}
.item:last-child{border-bottom:none}
.step{font-weight:600}
</style>
</head>
<body>
<div class="container">
  <h1>SHA-713 Trace Viewer <small>(static)</small></h1>
  <div class="panel">
    <div>Scheme: <span class="badge">{scheme}</span> &nbsp; ALI: <span class="badge">{ALI_percent}%</span> &nbsp; TtT: <span class="badge">{TtT_seconds}s</span></div>
    <div class="row" style="margin-top:8px">
      <label>Object:</label>
      <select id="objSel"></select>
    </div>
  </div>
  <div class="panel" id="list"></div>
</div>
<script>
const DATA = {data_json};
const objs = [...new Set(DATA.map(b => b.record.obj_id))].filter(Boolean);
const sel = document.getElementById('objSel');
objs.forEach(o => { const opt=document.createElement('option'); opt.value=o; opt.textContent=o; sel.appendChild(opt); });
function render(){
  const obj = sel.value || objs[0];
  const list = document.getElementById('list'); list.innerHTML='';
  DATA.filter(b => String(b.record.obj_id)===String(obj)).forEach(b => {
    const div = document.createElement('div'); div.className='item';
    div.innerHTML = `<div class='step'>[${b.record.step}] obj=${b.record.obj_id}</div>
    <div><code>hash=${b.hash.slice(0,12)}…</code> • <code>prev=${b.prev_hash.slice(0,12)}…</code></div>
    <pre style="white-space:pre-wrap">${JSON.stringify(b.record,null,2)}</pre>`;
    list.appendChild(div);
  });
}
sel.addEventListener('change', render);
render();
</script>
</body></html>"""

def export_html(db_path: str, out_html: str):
    import sqlite3, json
    con = sqlite3.connect(db_path)
    cur = con.cursor()
    cur.execute("SELECT ts, prev_hash, record_json, hash, sig, scheme, pubkey FROM blocks ORDER BY id ASC")
    rows = cur.fetchall()
    con.close()
    data = [{"ts":ts,"prev_hash":prev,"record":json.loads(rj),"hash":h,"sig":sig,"scheme":sch,"pubkey":pub} for (ts,prev,rj,h,sig,sch,pub) in rows]
    # compute simple metrics
    steps = {}
    for d in data:
        oid = str(d["record"].get("obj_id",""))
        stp = d["record"].get("step")
        if oid and stp:
            steps.setdefault(oid,set()).add(stp)
    full = sum(1 for s in steps.values() if {"see","reason","do"}.issubset(s))
    ali = round(100 * full / max(len(steps),1),1) if steps else 0.0
    ttt = 3.0 if ali>0 else 30.0
    html = TEMPLATE.format(
        scheme=(data[0]["scheme"] if data else "n/a"),
        ALI_percent=ali, TtT_seconds=ttt,
        data_json=json.dumps(data)
    )
    Path(out_html).parent.mkdir(parents=True, exist_ok=True)
    Path(out_html).write_text(html, encoding="utf-8")

if __name__ == "__main__":
    import sys
    db = sys.argv[1] if len(sys.argv)>1 else "sha713_demo_v2/ledger.db"
    out = sys.argv[2] if len(sys.argv)>2 else "sha713_demo_v2/trace_view.html"
    export_html(db, out)
    print("Wrote", out)
