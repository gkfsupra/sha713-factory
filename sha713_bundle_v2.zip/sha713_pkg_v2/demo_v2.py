
from pathlib import Path
from ingest_cv_v2 import run_demo
from build_view_html import export_html

db = "sha713_demo_v2/ledger.db"
out = "sha713_demo_v2/trace_view.html"
Path("sha713_demo_v2").mkdir(parents=True, exist_ok=True)

print("Running demo into", db)
res = run_demo(db, n_objects=4)
print("Result:", res)

export_html(db, out)
print("Viewer:", out)
