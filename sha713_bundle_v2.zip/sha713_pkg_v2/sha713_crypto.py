
"""
sha713_crypto.py
Ed25519 (preferred) with HMAC fallback.
- If 'cryptography' is available, we use Ed25519 for signatures.
- Otherwise, we fall back to HMAC-SHA256 (clearly labeled).
"""
from __future__ import annotations
import os, hmac, hashlib, base64
from typing import Tuple

USE_ED25519 = False
try:
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey
    from cryptography.hazmat.primitives import serialization
    USE_ED25519 = True
except Exception:
    USE_ED25519 = False

def ed25519_generate() -> Tuple[bytes, bytes]:
    if not USE_ED25519:
        raise RuntimeError("cryptography not available; cannot generate ed25519 keys")
    priv = Ed25519PrivateKey.generate()
    pub = priv.public_key()
    priv_pem = priv.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption())
    pub_pem = pub.public_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PublicFormat.SubjectPublicKeyInfo)
    return priv_pem, pub_pem

def ed25519_sign(priv_pem: bytes, payload: bytes) -> bytes:
    if not USE_ED25519:
        raise RuntimeError("cryptography not available; cannot sign with ed25519")
    from cryptography.hazmat.primitives import serialization
    priv = serialization.load_pem_private_key(priv_pem, password=None)
    return priv.sign(payload)

def ed25519_verify(pub_pem: bytes, payload: bytes, signature: bytes) -> bool:
    if not USE_ED25519:
        raise RuntimeError("cryptography not available; cannot verify ed25519 signature")
    from cryptography.hazmat.primitives import serialization
    pub = serialization.load_pem_public_key(pub_pem)
    try:
        pub.verify(signature, payload)
        return True
    except Exception:
        return False

# HMAC Fallback
def hmac_sign(secret: bytes, payload: bytes) -> bytes:
    return hmac.new(secret, payload, hashlib.sha256).digest()

def hmac_verify(secret: bytes, payload: bytes, signature: bytes) -> bool:
    return hmac.new(secret, payload, hashlib.sha256).digest() == signature

def b64(x: bytes) -> str:
    return base64.b64encode(x).decode("ascii")
