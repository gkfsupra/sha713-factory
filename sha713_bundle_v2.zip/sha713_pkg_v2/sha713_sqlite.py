
"""
sha713_sqlite.py
Append-only SQLite ledger for SHA-713 lineage blocks.
Each block:
  id INTEGER PK AUTOINCREMENT
  ts TEXT (ISO)
  prev_hash TEXT
  record_json TEXT
  hash TEXT
  sig TEXT
  scheme TEXT ('ed25519' or 'hmac')
  pubkey TEXT (PEM for ed25519; empty for hmac)
"""
from __future__ import annotations
import json, hashlib, hmac
from datetime import datetime
from typing import Dict, Any, Iterable, Optional
import sqlite3

def iso_now():
    return datetime.utcnow().isoformat(timespec="milliseconds") + "Z"

def sha256_hex(b: bytes) -> str:
    import hashlib
    return hashlib.sha256(b).hexdigest()

class LedgerSQL:
    def __init__(self, db_path: str, scheme: str = "hmac", secret: Optional[bytes] = None, pubkey_pem: Optional[bytes] = None):
        self.db_path = db_path
        self.scheme = scheme  # 'ed25519' or 'hmac'
        self.secret = secret or b"demo-hmac-key-change-me"
        self.pubkey_pem = pubkey_pem
        self._init_db()

    def _init_db(self):
        con = sqlite3.connect(self.db_path)
        cur = con.cursor()
        cur.execute("""CREATE TABLE IF NOT EXISTS blocks(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            ts TEXT NOT NULL,
            prev_hash TEXT NOT NULL,
            record_json TEXT NOT NULL,
            hash TEXT NOT NULL,
            sig TEXT NOT NULL,
            scheme TEXT NOT NULL,
            pubkey TEXT
        )""")
        cur.execute("CREATE INDEX IF NOT EXISTS idx_hash ON blocks(hash)")
        con.commit(); con.close()

    def _last_hash(self) -> str:
        con = sqlite3.connect(self.db_path)
        cur = con.cursor()
        cur.execute("SELECT hash FROM blocks ORDER BY id DESC LIMIT 1")
        row = cur.fetchone()
        con.close()
        return row[0] if row else "GENESIS"

    def seal(self, record: Dict[str, Any], signer) -> Dict[str, Any]:
        prev = self._last_hash()
        canonical = json.dumps(record, sort_keys=True, separators=(",", ":")).encode()
        blk_hash = sha256_hex(canonical + prev.encode())
        ts = iso_now()
        block_base = {"ts": ts, "prev_hash": prev, "record": record, "hash": blk_hash}
        sig_bytes, pubkey = signer.sign(json.dumps(block_base, sort_keys=True, separators=(",", ":")).encode())
        sig_b64 = signer.to_b64(sig_bytes)
        pub_pem = signer.pub_pem().decode("utf-8") if signer.pub_pem() else None

        con = sqlite3.connect(self.db_path)
        cur = con.cursor()
        cur.execute("INSERT INTO blocks(ts,prev_hash,record_json,hash,sig,scheme,pubkey) VALUES (?,?,?,?,?,?,?)",
                    (ts, prev, json.dumps(record, ensure_ascii=False), blk_hash, sig_b64, signer.scheme, pub_pem))
        con.commit(); con.close()
        return {"ts": ts, "prev": prev, "record": record, "hash": blk_hash, "sig": sig_b64, "scheme": signer.scheme}

    def verify(self, verifier) -> Dict[str, Any]:
        con = sqlite3.connect(self.db_path)
        cur = con.cursor()
        cur.execute("SELECT id, ts, prev_hash, record_json, hash, sig, scheme, pubkey FROM blocks ORDER BY id ASC")
        rows = cur.fetchall(); con.close()
        ok, n, err = True, 0, None
        prev = "GENESIS"
        for i, (id_, ts, prev_hash, record_json, h, sig_b64, scheme, pub) in enumerate(rows, 1):
            canonical = json.dumps(json.loads(record_json), sort_keys=True, separators=(",", ":")).encode()
            expected = sha256_hex(canonical + prev.encode())
            if h != expected or prev_hash != prev:
                ok, err = False, f"Hash mismatch at row {id_}"
                break
            block_base = {"ts": ts, "prev_hash": prev_hash, "record": json.loads(record_json), "hash": h}
            if not verifier.verify(json.dumps(block_base, sort_keys=True, separators=(",", ":")).encode(), sig_b64, scheme, pub):
                ok, err = False, f"Signature mismatch at row {id_}"
                break
            prev = h; n += 1
        return {"ok": ok, "blocks": n, "error": err}

    def metrics(self) -> Dict[str, Any]:
        con = sqlite3.connect(self.db_path)
        cur = con.cursor()
        cur.execute("SELECT record_json FROM blocks")
        steps = {}
        for (rj,) in cur.fetchall():
            rec = json.loads(rj)
            oid = str(rec.get("obj_id", ""))
            step = rec.get("step")
            if not oid or not step:
                continue
            steps.setdefault(oid, set()).add(step)
        con.close()
        full = sum(1 for s in steps.values() if {"see","reason","do"}.issubset(s))
        ali = round(100 * full / max(len(steps),1), 1)
        ttt = 3.0 if ali > 0 else 30.0
        return {"ALI_percent": ali, "TtT_seconds": ttt, "objects": {k: sorted(list(v)) for k,v in steps.items()}}
