
"""
signer.py
Signer/Verifier abstraction supporting 'ed25519' (if available) and 'hmac' fallback.
"""
from __future__ import annotations
import base64, os
from typing import Optional, Tuple
from sha713_crypto import USE_ED25519, ed25519_generate, ed25519_sign, ed25519_verify, hmac_sign, hmac_verify, b64

class Signer:
    def __init__(self, scheme: str = "ed25519", secret: Optional[bytes] = None, priv_pem: Optional[bytes] = None, pub_pem: Optional[bytes] = None):
        self.scheme = scheme if (scheme=="ed25519" and USE_ED25519) else "hmac"
        self._secret = secret or os.environ.get("SHA713_HMAC_KEY", "demo-hmac-key-change-me").encode()
        self._priv = priv_pem
        self._pub = pub_pem

        if self.scheme == "ed25519" and self._priv is None:
            # try generate if not provided
            try:
                priv, pub = ed25519_generate()
                self._priv, self._pub = priv, pub
            except Exception:
                # fallback
                self.scheme = "hmac"

    def sign(self, payload: bytes) -> Tuple[bytes, Optional[bytes]]:
        if self.scheme == "ed25519":
            sig = ed25519_sign(self._priv, payload)
            return sig, self._pub
        else:
            sig = hmac_sign(self._secret, payload)
            return sig, None

    def verify(self, payload: bytes, sig_b64: str, scheme: str, pub_pem: Optional[str]) -> bool:
        sig = base64.b64decode(sig_b64.encode("ascii"))
        if scheme == "ed25519" and USE_ED25519 and pub_pem:
            return ed25519_verify(pub_pem.encode("utf-8"), payload, sig)
        else:
            return hmac_verify(self._secret, payload, sig)

    def to_b64(self, sig_bytes: bytes) -> str:
        return base64.b64encode(sig_bytes).decode("ascii")

    def pub_pem(self) -> Optional[bytes]:
        return self._pub
