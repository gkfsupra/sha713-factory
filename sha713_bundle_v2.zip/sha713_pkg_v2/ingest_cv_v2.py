
"""
ingest_cv_v2.py — simulate CV pipeline into SQLite + signatures
"""
from __future__ import annotations
import random
from sha713_sqlite import LedgerSQL
from signer import Signer

RULES = {
    "detector": {"min_conf": 0.80},
    "reasoner": {"min_track_conf": 0.85, "min_velocity": 0.8},
    "action": {"alert_threshold": 1},
}

def simulate_detection(obj_id: int) -> dict:
    conf = round(random.uniform(0.75, 0.97), 2)
    rec = {"step":"see","obj_id":obj_id,"confidence":conf,"rule_min_conf":RULES["detector"]["min_conf"]}
    rec["decision"] = "accept" if conf >= RULES["detector"]["min_conf"] else "reject"
    return rec

def simulate_reason(prev: dict) -> dict:
    vel = round(random.uniform(0.6, 1.0), 2)
    track_conf = round(max(prev["confidence"], vel - 0.05), 2)
    decision = "track" if (track_conf >= RULES["reasoner"]["min_track_conf"] and vel >= RULES["reasoner"]["min_velocity"]) else "discard"
    return {"step":"reason","obj_id":prev["obj_id"],"track_conf":track_conf,"velocity_score":vel,
            "rule_min_track_conf":RULES["reasoner"]["min_track_conf"],"rule_min_velocity":RULES["reasoner"]["min_velocity"],
            "decision":decision}

def simulate_do(reason_out: dict) -> dict:
    alert = 1 if reason_out["decision"] == "track" else 0
    return {"step":"do","obj_id":reason_out["obj_id"],"action":"alert" if alert else "none",
            "alert_count":alert,"rule_alert_threshold":RULES["action"]["alert_threshold"]}

def run_demo(db_path: str, n_objects: int = 3, seed: int = 713):
    random.seed(seed)
    signer = Signer("ed25519")  # will fall back to HMAC if ed25519 not available
    ledger = LedgerSQL(db_path, scheme=signer.scheme)
    for oid in range(1, n_objects+1):
        r1 = simulate_detection(oid); ledger.seal(r1, signer)
        if r1["decision"] == "accept":
            r2 = simulate_reason(r1); ledger.seal(r2, signer)
            r3 = simulate_do(r2);     ledger.seal(r3, signer)
    return {"verify": ledger.verify(signer), "metrics": ledger.metrics(), "scheme": signer.scheme}

if __name__ == "__main__":
    out = run_demo("sha713_demo_v2/ledger.db", n_objects=5)
    print(out)
