
# SHA-713 Package v2 — ed25519-ready + SQLite + Static Viewer

## Files
- `sha713_crypto.py` — Ed25519 (if available) + HMAC fallback
- `signer.py` — signer/verifier abstraction
- `sha713_sqlite.py` — append-only SQLite ledger
- `ingest_cv_v2.py` — CV simulation → ledger
- `build_view_html.py` — generates `trace_view.html` with embedded data
- `demo_v2.py` — runs end-to-end demo

## Quickstart
```bash
python /mnt/data/sha713_pkg_v2/demo_v2.py
# open the generated static viewer:
# /mnt/data/sha713_pkg_v2/../sha713_demo_v2/trace_view.html
```

## Notes
- If `cryptography` is installed, signatures use **ed25519** automatically. Otherwise HMAC-SHA256 is used (clearly labeled).
- Ledger is append-only in SQLite. To harden, use DB write-ahead logging, restricted users, and integrity checks.
- The HTML viewer embeds the data so you can open it offline and replay in <30s.
