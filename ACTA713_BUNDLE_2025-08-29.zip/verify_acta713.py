#!/usr/bin/env python3
import sys, json, hashlib, os

def sha256_file(path):
    with open(path, "rb") as f:
        return hashlib.sha256(f.read()).hexdigest()

def main(pdf_path, manifest_path):
    with open(manifest_path, "r", encoding="utf-8") as f:
        mani = json.load(f)
    target = os.path.basename(pdf_path)
    record = next((f for f in mani.get("files", []) if f.get("filename")==target), None)
    if not record:
        print("❌ Archivo no declarado en MANIFEST-713.json"); sys.exit(2)
    h = sha256_file(pdf_path)
    ok = (h == record.get("sha256"))
    print("Archivo:", target)
    print("HASH local :", h)
    print("HASH manifiesto:", record.get("sha256"))
    print("Resultado:", "✅ COINCIDE" if ok else "❌ NO COINCIDE")
    sys.exit(0 if ok else 1)

if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("Uso: python3 verify_acta713.py <PDF> <MANIFEST-713.json>"); sys.exit(1)
    main(sys.argv[1], sys.argv[2])
