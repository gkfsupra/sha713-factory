#!/usr/bin/env python3
import os, json, hashlib, base64, time, re, pathlib
from datetime import datetime, timezone

ROOT = pathlib.Path(__file__).resolve().parents[1]
DROPS = ROOT / "drops"
DOCS  = ROOT / "docs"
AUTO  = DOCS / "CodexAuto"
TOKENS = DOCS / "tokens.json"

def sha256_hex(b): 
    import hashlib
    return hashlib.sha256(b).hexdigest()

def make_token_bytes(content, subject, author):
    h0 = sha256_hex(content)
    nonce = os.urandom(16).hex()
    h1 = hashlib.sha256(bytes.fromhex(h0) + bytes.fromhex(nonce)).hexdigest()
    h2 = hashlib.sha256(bytes.fromhex(h1) + author.encode("utf-8")).hexdigest()
    token_id = h2[:32]
    tok = {
      "type":"sha713-token","version":"713.1-exp","token_id":token_id,
      "timestamp_utc": datetime.now(timezone.utc).isoformat(),
      "subject": subject, "author": author, "content_sha256": h0, "nonce_hex": nonce,
      "hash_chain":{"h0":h0,"h1":h1,"h2":h2},
      "notes":"Symbolic PoSE - Human-verifiable."
    }
    compact = "sha713://" + base64.urlsafe_b64encode(
        json.dumps(tok, ensure_ascii=False, separators=(",",":")).encode("utf-8")
    ).decode("ascii").rstrip("=")
    return tok, compact

def slugify(name):
    s = re.sub(r'[^a-zA-Z0-9\-]+','-', name.strip().lower()).strip('-')
    return s[:50] or ("codex-" + str(int(time.time())))

def ensure_json(path, default):
    if not path.exists():
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(default, ensure_ascii=False, indent=2), encoding="utf-8")
    return json.loads(path.read_text(encoding="utf-8"))

def write(p, txt):
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(txt, encoding="utf-8")

def main():
    author = os.environ.get("SHA713_AUTHOR","Giankoof | GKF IA")
    tokens = ensure_json(TOKENS, [])
    known = {t.get("content_sha256","") for t in tokens}
    minted = 0

    for fp in DROPS.glob("*"):
        if not fp.is_file(): continue
        data = fp.read_bytes()
        h0 = sha256_hex(data)
        if h0 in known:
            print("[skip] already minted:", fp.name)
            continue

        subject = fp.stem
        tok, uri = make_token_bytes(data, subject, author)
        slug = slugify(fp.stem)
        dest = AUTO / slug
        dest.mkdir(parents=True, exist_ok=True)

        (dest / "payload.bin").write_bytes(data)
        write(dest / "sha713_token.json", json.dumps(tok, ensure_ascii=False, indent=2))
        write(dest / "sha713_token.txt", uri)

        html = "<!doctype html><meta charset='utf-8'><title>" + slug + " - SHA-713</title><div>" + slug + " minted.</div>"
        write(dest / "index.html", html)

        tokens.append({
          "token_id": tok["token_id"],
          "subject": subject,
          "author": author,
          "content_sha256": tok["content_sha256"],
          "timestamp_utc": tok["timestamp_utc"],
          "links":{"post_url":"","arweave":"","github":"","qr":""},
          "status":"issued"
        })
        minted += 1
        print("[minted]", slug)

    write(TOKENS, json.dumps(tokens, ensure_ascii=False, indent=2))
    print("[done] minted=", minted)

if __name__ == "__main__":
    main()
