#!/usr/bin/env python3
import json, sys, pathlib

ROOT = pathlib.Path(__file__).resolve().parents[1]
DOCS = ROOT / "docs"

def load(p): 
    with open(p,'r',encoding='utf-8') as f: return json.load(f)

def score(evt, rules):
    rt = rules["events"].get(evt["type"])
    if not rt: return 0.0
    s = float(rt.get("base",0))
    mul = rt.get("multipliers",{})
    for k,v in (evt.get("weights") or {}).items():
        if k in mul:
            s += float(mul[k])*float(v)
    return s

def main():
    rules = load(DOCS/'siat_rules.json')
    ledger = load(DOCS/'siat_ledger.json')
    bal = {}
    for evt in ledger.get("events",[]):
        actor = evt["actor"]
        bal[actor] = bal.get(actor, 0.0) + score(evt, rules)
    with open(DOCS/'siat_balances.json','w',encoding='utf-8') as f: json.dump(bal, f, ensure_ascii=False, indent=2)
    html = "<!doctype html><meta charset='utf-8'><div>ΣIAT Leaderboard</div>"
    with open(DOCS/'siat_leaderboard.html','w',encoding='utf-8') as f: f.write(html)
    print("[OK] balances & leaderboard updated")

if __name__ == "__main__":
    main()
