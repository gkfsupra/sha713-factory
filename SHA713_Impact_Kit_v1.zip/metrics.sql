-- Core KPI queries (Postgres)

-- 1) Monthly Active Orgs (MAO)
with last30 as (
  select distinct org_id
  from fact_event
  where ts >= now() - interval '30 days'
)
select count(*) as orgs_active_m from last30;

-- 2) New Integrations per Quarter
with installs as (
  select org_id, min(ts) as first_install
  from fact_event
  where event_name='install'
  group by org_id
)
select date_trunc('quarter', first_install) as quarter, count(*) as integrations_new_t
from installs
group by 1
order by 1 desc;

-- 3) DAU/MAU (stickiness) - last 30 days
with dau as (
  select date_trunc('day', ts) d, count(distinct org_id) dau
  from fact_event
  group by 1
), mau as (
  select count(distinct org_id) mau
  from fact_event
  where ts >= now() - interval '30 days'
)
select avg(dau)::numeric / (select mau from mau) as dau_mau
from dau
where d >= now() - interval '30 days';

-- 4) Activation ≤ 7 days
with init_times as (
  select org_id, min(ts) as t_init
  from fact_event
  where event_name='init'
  group by org_id
), success_times as (
  select org_id, min(ts) as t_success
  from fact_event
  where event_name='first_success'
  group by org_id
)
select
  count(*) filter (where t_success is not null and t_success <= t_init + interval '7 days')::numeric
  / nullif(count(*),0) as activation_rate
from init_times it
left join success_times st using(org_id);

-- 5) Median TTV (hours)
with ttv as (
  select it.org_id, extract(epoch from (st.t_success - it.t_init))/3600.0 as ttv_hours
  from (select org_id, min(ts) as t_init from fact_event where event_name='init' group by org_id) it
  join (select org_id, min(ts) as t_success from fact_event where event_name='first_success' group by org_id) st
    on it.org_id = st.org_id
)
select percentile_cont(0.5) within group(order by ttv_hours) as ttv_hours_median from ttv;

-- 6) Share de carga (requests)
select
  sum(req_sha713)::numeric / nullif(sum(req_total),0) as share_carga
from fact_requests_daily
where date >= date_trunc('month', now());

-- 7) p95 improvement
with apm as (
  select date, org_id, p95_ms, p95_ms_base from fact_apm_daily
  where date >= date_trunc('month', now())
)
select avg(1 - (p95_ms / nullif(p95_ms_base,0))) as p95_improvement_pct from apm;

-- 8) Cost per 1M ops
select
  avg( (usd_sha713 / nullif(ops_sha713,0)) * 1000000.0 ) as usd_per_1m_ops_sha713
from fact_billing_monthly
where month >= date_trunc('month', now());

-- 9) Incidents per 1k requests
select avg(errors_per_1k) as incidents_per_1k_req
from fact_apm_daily
where date >= date_trunc('month', now());

-- 10) NRR
select
  quarter,
  (revenue_t1 - contractions + expansions) / nullif(revenue_t0,0) as nrr_pct
from fact_revenue_quarterly
order by quarter desc;

-- --- Composite Indices require normalized inputs (z to 0-100) using metrics_targets.csv ---
