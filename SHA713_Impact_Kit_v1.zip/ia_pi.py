# Compute IA (Index of Adoption) & PI (Impact Score) from aggregated metrics
# Usage: python ia_pi.py metrics_aggregated.csv metrics_targets.csv
import sys, pandas as pd, json

def load_inputs(agg_path, targets_path):
    agg = pd.read_csv(agg_path)
    tgt = pd.read_csv(targets_path)
    # Expect columns:
    # agg: metric_key, value
    # tgt: metric_key, p10, p90, direction (higher_is_better|lower_is_better)
    return agg, tgt

def to_score(value, p10, p90, direction):
    if p90 == p10:
        return 50.0
    if direction == "lower_is_better":
        # invert by swapping
        value = p10 + (p90 - value)
        # simple approach: transform so lower maps to higher score
        # We'll fall back to the same min-max scaling after inversion
    x = (value - p10) / (p90 - p10)
    x = max(0.0, min(1.0, x))
    return x * 100.0

def main():
    if len(sys.argv) < 3:
        print("Usage: python ia_pi.py metrics_aggregated.csv metrics_targets.csv")
        sys.exit(1)
    agg, tgt = load_inputs(sys.argv[1], sys.argv[2])
    merged = agg.merge(tgt, on="metric_key", how="left")
    if merged['p10'].isna().any():
        missing = merged[merged['p10'].isna()]['metric_key'].tolist()
        raise ValueError(f"Missing targets for metrics: {missing}")
    merged['score_0_100'] = merged.apply(
        lambda r: to_score(r['value'], r['p10'], r['p90'], r['direction']), axis=1
    )
    # Weights for IA
    ia_weights = {
      "adoption.orgs_active_m": 0.30,
      "adoption.integrations_new_t": 0.20,
      "adoption.dau_mau": 0.10,
      "adoption.marketplace_installs": 0.10,
      "adoption.partners_tier1": 0.10,
      "adoption.rfps_requiring": 0.10,
      "adoption.ttv_hours_median": 0.10  # inverted via targets
    }
    # Weights for PI
    pi_weights = {
      "impact.unit_cost_savings_pct": 0.25,
      "impact.p95_improvement_pct": 0.15,
      "impact.qps_per_dollar_improvement_pct": 0.15,
      "impact.incidents_per_1k_req": 0.10,  # inverted via targets
      "impact.nrr_pct": 0.15,
      "impact.case_studies_tier1": 0.10,
      "impact.standardization_refs": 0.10
    }
    scores = merged.set_index("metric_key")['score_0_100'].to_dict()

    def composite(weights):
        return sum(scores.get(k, 0) * w for k, w in weights.items())

    IA = composite(ia_weights)
    PI = composite(pi_weights)

    out = pd.DataFrame([
        {"composite": "IA", "value": round(IA, 2)},
        {"composite": "PI", "value": round(PI, 2)}
    ])
    out.to_csv("IA_PI_summary.csv", index=False)

    # Expand detailed view
    detail = merged[['metric_key','value','p10','p90','direction','score_0_100']]
    detail.to_csv("IA_PI_details.csv", index=False)

    print("Computed IA and PI. Files written: IA_PI_summary.csv, IA_PI_details.csv")

if __name__ == "__main__":
    main()
