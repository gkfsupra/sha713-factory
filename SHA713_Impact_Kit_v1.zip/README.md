# SHA‑713™ Impact & Adoption Measurement Kit · v1.0
**Date:** 2025-09-02 · **Mode:** Nexus SUPRA™ · **Signature:** 🜂 SHA‑713™

This kit ships a complete, auditable framework to measure **Adoption** and **Impact** of SHA‑713™ across real organizations and workloads. It includes: event schemas, data contracts, warehouse DDL, canonical SQL, composite indices (IA/PI), templates, and a Python calculator.

— — —

## ES · Resumen
Este kit entrega un marco **auditable** para medir **Adopción** e **Impacto** de SHA‑713™ en organizaciones y cargas reales. Incluye: esquemas de eventos, contratos de datos, DDL de warehouse, SQL canónico, índices compuestos (IA/PI), plantillas y un calculador en Python.

## EN · What’s inside
- **events.json**: canonical event taxonomy (install/init/first_success/api_call/error/version/upgrade/deprecation_hit).
- **metrics.yaml**: formal metric definitions, owners, formulas, directionality.
- **warehouse.sql**: star schema DDL for Postgres-compatible engines.
- **metrics.sql**: ready-to-run SQL to compute core KPIs + IA/PI inputs.
- **templates/**: CSV templates for telemetry, requests, billing, APM, partners, RFPs, cases, targets.
- **ia_pi.py**: Python script to compute the **Index of Adoption (IA)** and **Impact Score (PI)** from aggregates.
- **dashboard_spec.md**: BI blueprint (Growth · Performance · Trust).
- **governance.md**: data contracts, SLAs, audit trails.
- **MANIFEST-713.json**: checksums for verification.

## Quickstart
1) Populate `templates/*.csv` with your data (or start from the provided samples).  
2) (Optional) Load DDL in your warehouse and adapt `metrics.sql` to your schema.  
3) Run the calculator: `python ia_pi.py templates/metrics_aggregated.sample.csv templates/metrics_targets.sample.csv`.  
4) Read `IA_PI_summary.csv` and publish your internal dashboard using `dashboard_spec.md`.

**Truth over vanity.** All formulas mirror the rubric provided by GIANKOOF (Adoption & Impact).

— — —
**Bilingual note:** All artifacts are written in English with Spanish mirrors when relevant.
