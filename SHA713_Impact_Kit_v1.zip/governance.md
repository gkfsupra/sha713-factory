# Governance · Data Contracts · SLAs

## Data Contracts
- **Telemetry**: `events.json` schema is authoritative. Reject events missing required fields.
- **Latency**: report in milliseconds; p95_base is immutable baseline snapshot per workload.
- **Costs**: costs in USD; `cost_usd_per_op` aligns with billing month aggregates.
- **Energy**: joules per operation; aggregate to kWh/100k ops.

## SLAs
- Event ingestion < 2 minutes end-to-end.
- Metric freshness: daily (00:30 UTC); quarterly NRR post month-close.
- QA: sampling 1% events vs. warehouse reconciliation.

## Audit & Provenance
- Keep `MANIFEST-713.json` with file checksums.
- Tag warehouse snapshots with immutable hash; store queries in VCS.
- Maintain runbooks for experiments (holdout, DiD) with seed and cohorts pinned.
