# Dashboard Spec — Growth · Performance · Trust (Nexus SUPRA™)

## 1) Growth
- KPI tiles: Orgs Active (M), New Integrations (Q), DAU/MAU, Marketplace Installs
- Charts:
  - Line: Integrations vs. Orgs Actives (12m)
  - Funnel: Install → Init → First Success (≤7d)
  - Bar: RFPs requiring SHA-713™ by region (Q)
  - Map: Partner Tier-1 coverage

## 2) Performance
- KPI tiles: p95 Improvement %, QPS/$ Improvement %, $/1M ops
- Charts:
  - Line: p95 base vs. new (5 standard workloads)
  - Box: TTV distribution (hours)
  - Line: Energy (kWh/100k ops) — if available
  - Table: Workload benchmarks

## 3) Trust
- KPI tiles: SLA %, Incidents/1k req, NRR %, Case Studies Tier-1
- Charts:
  - Line: Availability by org cohort
  - Bar: CVEs closed and audits passed
  - Waterfall: NRR components (expansion vs contraction)
  - Table: Case studies (savings %, quote, link)

## IA & PI
- Composite gauge widgets (0-100) for IA and PI
- Attribution view: contribution by component metric (stacked bar)

Filters: date range, region, plan, vertical, runtime.
