-- SHA-713™ Warehouse DDL (Postgres compatible)
create table if not exists dim_org (
  org_id text primary key,
  org_name text,
  plan text,
  region text,
  created_at timestamp
);

create table if not exists fact_event (
  event_id uuid primary key,
  ts timestamp not null,
  event_name text not null,
  org_id text references dim_org(org_id),
  user_id text,
  runtime text,
  region text,
  cloud text,
  product_id text,
  sdk_version text,
  latency_ms numeric,
  energy_j numeric,
  cost_usd_per_op numeric,
  success boolean,
  error_code text
);

create index if not exists idx_event_ts on fact_event(ts);
create index if not exists idx_event_org on fact_event(org_id);
create index if not exists idx_event_name on fact_event(event_name);

create table if not exists fact_requests_daily (
  date date,
  org_id text references dim_org(org_id),
  req_total bigint,
  req_sha713 bigint,
  primary key (date, org_id)
);

create table if not exists fact_billing_monthly (
  month date,
  org_id text references dim_org(org_id),
  usd_total numeric,
  usd_sha713 numeric,
  ops_total bigint,
  ops_sha713 bigint,
  primary key (month, org_id)
);

create table if not exists fact_apm_daily (
  date date,
  org_id text references dim_org(org_id),
  p50_ms numeric,
  p95_ms numeric,
  p95_ms_base numeric,
  throughput_qps numeric,
  errors_per_1k numeric,
  availability numeric,
  primary key (date, org_id)
);

create table if not exists dim_partner (
  partner_id text primary key,
  name text,
  tier int,
  certified boolean,
  certified_at date
);

create table if not exists fact_rfp (
  rfp_id text primary key,
  date date,
  vendor text,
  region text,
  require_sha713 boolean
);

create table if not exists fact_cases (
  case_id text primary key,
  org_id text references dim_org(org_id),
  date date,
  tier int,
  savings_pct numeric,
  verified boolean
);

create table if not exists fact_revenue_quarterly (
  quarter date,
  cohort text,
  revenue_t0 numeric,
  expansions numeric,
  contractions numeric,
  revenue_t1 numeric,
  primary key (quarter, cohort)
);
