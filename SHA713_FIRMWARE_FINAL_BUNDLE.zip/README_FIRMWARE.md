# SHA713 Firmware
This is the README for the firmware.