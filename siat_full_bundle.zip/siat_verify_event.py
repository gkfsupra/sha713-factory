#!/usr/bin/env python3
import sys, json, hashlib, argparse

def sha256_hex(b): return hashlib.sha256(b).hexdigest()

def verify_chain(tok):
    h0 = tok.get("content_sha256","")
    h1 = hashlib.sha256(bytes.fromhex(h0) + bytes.fromhex(tok["nonce_hex"])).hexdigest()
    ok_h1 = (h1.lower() == tok["hash_chain"]["h1"].lower())
    h2 = hashlib.sha256(bytes.fromhex(h1) + tok["author"].encode("utf-8")).hexdigest()
    ok_h2 = (h2.lower() == tok["hash_chain"]["h2"].lower())
    tid = h2[:32]
    ok_tid = (tid.lower() == tok["token_id"].lower())
    return {"ok_h1":ok_h1,"ok_h2":ok_h2,"ok_tid":ok_tid,"h1":h1,"h2":h2,"tid":tid}

def main():
    ap = argparse.ArgumentParser(description="Verify SHA‑713 chain for an event token")
    ap.add_argument("token_json")
    ap.add_argument("--content", help="optional content file to verify H0", default=None)
    args = ap.parse_args()

    tok = json.load(open(args.token_json,'r',encoding='utf-8'))
    res = verify_chain(tok)

    if args.content:
        with open(args.content,'rb') as f: data = f.read()
        h0 = sha256_hex(data)
        res["ok_h0"] = (h0.lower() == tok.get("content_sha256","").lower())
        res["h0"] = h0

    print(json.dumps(res, indent=2))

if __name__ == "__main__":
    main()
