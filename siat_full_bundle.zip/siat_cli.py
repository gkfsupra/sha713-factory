#!/usr/bin/env python3
import json, sys, hashlib, argparse, os, datetime

def load(path): 
    with open(path,'r',encoding='utf-8') as f: return json.load(f)
def save(path, obj):
    with open(path,'w',encoding='utf-8') as f: json.dump(obj,f,ensure_ascii=False,indent=2)

def did_for(handle, name):
    norm = (handle.strip().lower() + "|" + name.strip()).encode("utf-8")
    return "did:siat:" + hashlib.sha256(norm).hexdigest()[:32]

def score(event, rules):
    rt = rules["events"][event["type"]]
    base = rt["base"]
    mul = 0.0
    for k,v in (event.get("weights") or {}).items():
        if k in rt.get("multipliers",{}):
            mul += rt["multipliers"][k] * float(v)
    return base + mul

def cmd_init(args):
    if os.path.exists(args.ledger): print("Ledger exists. Aborting."); sys.exit(1)
    ledger = {"version":"0.1-draft","events":[]}
    save(args.ledger, ledger); print("[OK] created", args.ledger)

def cmd_add(args):
    ledger = load(args.ledger)
    evt = load(args.event)
    ledger["events"].append(evt)
    save(args.ledger, ledger); print("[OK] appended event", evt.get("id"))

def cmd_balance(args):
    ledger = load(args.ledger)
    rules = load(args.rules)
    bal = {}
    for evt in ledger["events"]:
        s = score(evt, rules)
        actor = evt["actor"]
        bal[actor] = bal.get(actor, 0) + s
    print(json.dumps(bal, indent=2, ensure_ascii=False))

def main():
    ap = argparse.ArgumentParser(description="ΣIAT CLI")
    sub = ap.add_subparsers(dest="cmd")
    p_init = sub.add_parser("init"); p_init.add_argument("ledger"); p_init.set_defaults(func=cmd_init)
    p_add = sub.add_parser("add-event"); p_add.add_argument("ledger"); p_add.add_argument("event"); p_add.set_defaults(func=cmd_add)
    p_bal = sub.add_parser("balance"); p_bal.add_argument("ledger"); p_bal.add_argument("rules"); p_bal.set_defaults(func=cmd_balance)
    args = ap.parse_args()
    if not args.cmd: ap.print_help(); sys.exit(1)
    args.func(args)

if __name__ == "__main__":
    main()
