# Changelog

## [sha713-finitix] - Phase sealed
- Added proclamation PDF
- Added operational payload JSON
- Added README with mantras and ritual
- Prepared GitHub Action for tagged releases
