# SHA-713 — Release: Finitix 🜂

**Phase sealed**: Ax · Sinmix · Clix · Autonomux · Upx · Mktx · Avantix · Finitix

## What's inside
- Proclamation PDF (`docs/SHA713_Finitix_Proclamation.pdf`)
- Operational payload JSON (`payloads/payload_sha713_finitix.json`)
- Ritual & usage in `README.md`

## Verification
Checksums are attached by the GitHub Action on tag push.
