#!/usr/bin/env python3
import os, sys, hashlib, base64

def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            h.update(chunk)
    return h.hexdigest()

def main():
    if len(sys.argv) < 2:
        print("Usage: hash_and_qr.py <input_dir> --out <qr_dir>")
        sys.exit(1)
    in_dir = sys.argv[1]
    out_dir = "qr"
    if "--out" in sys.argv:
        out_dir = sys.argv[sys.argv.index("--out")+1]
    os.makedirs(out_dir, exist_ok=True)
    for root, _, files in os.walk(in_dir):
        for fn in files:
            path = os.path.join(root, fn)
            h = sha256_file(path)
            payload = f"sha256:{h}"
            # Try to build QR if 'qrcode' available; otherwise make placeholder SVG
            try:
                import qrcode
                img = qrcode.make(payload)
                png_path = os.path.join(out_dir, f"{fn}.qr.png")
                img.save(png_path)
                with open(png_path, "rb") as fp:
                    b64 = base64.b64encode(fp.read()).decode("ascii")
                svg = f'<svg xmlns="http://www.w3.org/2000/svg" width="512" height="512"><image href="data:image/png;base64,{b64}" x="0" y="0" height="512" width="512"/></svg>'
            except Exception:
                svg = f'''<svg xmlns="http://www.w3.org/2000/svg" width="512" height="512">
<rect width="100%" height="100%" fill="white"/>
<rect x="16" y="16" width="480" height="480" fill="none" stroke="black" stroke-width="8"/>
<text x="50%" y="50%" dominant-baseline="middle" text-anchor="middle" font-size="22" font-family="monospace" fill="black">
QR placeholder — {payload[:24]}...
</text>
</svg>'''
            out_svg = os.path.join(out_dir, f"{fn}.svg")
            with open(out_svg, "w") as f:
                f.write(svg)
            print(f"{fn}\t{h}\t-> {out_svg}")

if __name__ == "__main__":
    main()
