#!/usr/bin/env python3
import os, json, hashlib, datetime

BASE = os.path.dirname(os.path.dirname(__file__))

def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            h.update(chunk)
    return h.hexdigest()

def main():
    bundles = os.path.join(BASE, "bundles")
    qrdir = os.path.join(BASE, "qr")
    artifacts = []
    for fn in sorted(os.listdir(bundles)):
        fpath = os.path.join(bundles, fn)
        if os.path.isfile(fpath):
            h = sha256_file(fpath)
            qrf = os.path.join("qr", f"{fn}.svg")
            artifacts.append({"file": f"bundles/{fn}", "sha256": h, "qr": qrf})
    manifest = {
        "bundle": "GKF-713 · Auto",
        "artifacts": artifacts,
        "author": "Giankoof · 🜂 SHA-713™",
        "date": datetime.date.today().isoformat(),
        "notes": "Auto-actualizado por CI · PoSE"
    }
    with open(os.path.join(BASE, "MANIFEST-713.json"), "w") as f:
        json.dump(manifest, f, indent=2, ensure_ascii=False)
    print("MANIFEST-713.json actualizado.")

if __name__ == "__main__":
    main()
