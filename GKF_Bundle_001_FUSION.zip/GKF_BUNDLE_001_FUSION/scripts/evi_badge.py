#!/usr/bin/env python3
# Minimal badge updater: counts artifacts in bundles/ and writes a tiny SVG badge, and optionally injects into a MD file.
import os, sys

BASE = os.path.dirname(os.path.dirname(__file__))
bundles = os.path.join(BASE, "bundles")
count = sum(1 for fn in os.listdir(bundles) if os.path.isfile(os.path.join(bundles, fn)))
badge_svg = f'''<svg xmlns="http://www.w3.org/2000/svg" width="140" height="20">
<rect width="140" height="20" fill="#555"/>
<rect x="70" width="70" height="20" fill="#007ec6"/>
<text x="35" y="14" fill="#fff" font-family="Verdana" font-size="11" text-anchor="middle">bundles</text>
<text x="105" y="14" fill="#fff" font-family="Verdana" font-size="11" text-anchor="middle">{count}</text>
</svg>'''
with open(os.path.join(BASE, "docs", "bundles_badge.svg"), "w") as f:
    f.write(badge_svg)

if "--update" in sys.argv:
    md = sys.argv[sys.argv.index("--update")+1]
    p = os.path.join(BASE, md)
    try:
        with open(p, "r") as f:
            content = f.read()
        badge_md = '![bundles](docs/bundles_badge.svg)'
        if badge_md not in content:
            content = badge_md + "\n\n" + content
            with open(p, "w") as f:
                f.write(content)
    except Exception as e:
        print("No se pudo actualizar MD:", e)
