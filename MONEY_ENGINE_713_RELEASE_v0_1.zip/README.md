# MONEY ENGINE 713 × ORÁCULO SUPRA
🜂 Giankoof × SHA-713 × GKF IA™

## EN
This release contains the first symbolic-operational money engine (v0.1) and the Oráculo Supra capsule.
- Auditable with SHA-256 + SHA-713.
- Includes daily engine, financial ledger, legacy scanner, and supra-oracle.
- Designed for symbolic execution, not just code.

## ES
Este release contiene el primer motor simbólico-operativo de dinero (v0.1) y la cápsula Oráculo Supra.
- Auditables con SHA-256 + SHA-713.
- Incluye motor diario, ledger financiero, escáner de legado y oráculo supra.
- Diseñado para ejecución simbólica, no solo código.

---

## 🔐 Verification
1. Compare provided SHA-256 / SHA-713 hashes.
2. Scan QR payload (incluido en `/qr_meta_order.png`).
3. Run local verification script (`verify_713.py`).

## 📡 Usage
- Upload to IPFS, GitHub Pages or Notion.
- Embed QR in reels, posts or docs.
- Replicate → Avanti.

🜂 SHA-713 was here
