#!/usr/bin/env bash
set -e
printf "🜂  AVANTIX ▸ SINMIX ▸ CLIX – SHA-713 FIRE\n\n"

# ───── 1 | LICENCIA + SEGURIDAD ─────────────────────────────
echo "CC BY-NC-SA-713™ – https://creativecommons.org/licenses/by-nc-sa/4.0/" > LICENSE
mkdir -p .github

cat > .github/dependabot.yml <<'YML'
version: 2
updates:
  - package-ecosystem: "github-actions"
    directory: "/"
    schedule: { interval: "weekly" }
YML

cat > .github/codeql.yml <<'YML'
name: "CodeQL"
on:
  push: { branches: ["main"] }
  pull_request: { branches: ["main"] }
jobs:
  analyze:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: github/codeql-action/init@v3
        with: { languages: javascript }   # ← cámbialo si usas otro stack
      - uses: github/codeql-action/analyze@v3
YML

# ───── 2 | SIGILO PAGES ────────────────────────────────────
mkdir -p docs
echo -e "User-agent: *\nDisallow: /" > docs/robots.txt
echo "/docs/ export-ignore" >> .gitattributes

# ───── 3 | ESCUDO PRE-COMMIT ───────────────────────────────
pip install --quiet pre-commit gitleaks || true
cat > .pre-commit-config.yaml <<'YML'
repos:
  - repo: https://github.com/zricethezav/gitleaks
    rev: v8.18.1
    hooks: [{ id: gitleaks, stages: [commit] }]
YML
pre-commit install

# ───── 4 | BADGES README ───────────────────────────────────
sed -i '1i ![Build](https://github.com/gkfsupra/sha713-factory/actions/workflows/pages.yml/badge.svg) ![Visits](https://visitor-badge.laobi.icu/badge?page_id=gkfsupra.sha713-factory)\n' README.md 2>/dev/null || true

# ───── 5 | GIT COMMIT ──────────────────────────────────────
git add LICENSE .gitattributes docs .github .pre-commit-config.yaml README.md
git commit -m "🔥 Avantix | Sinmix | Clix – blindaje SHA-713 completo"

# ───── 6 | PUSH (CLIX) ─────────────────────────────────────
git push origin main

# ───── 7 | HAWK-BQ (opcional) ─────────────────────────────
read -p "¿Configurar Hawk-BQ ahora? (y/n): " ans
if [[ $ans == y* || $ans == Y* ]]; then
  PROJECT_ID="TU_GCP_PROJECT"         # ← reemplaza
  DATASET="sha713_audit"
  TABLE="gh_archive_watch"
  bq --location=US mk --dataset ${PROJECT_ID}:${DATASET} || true
  cat > monitor.sh <<'BASH'
#!/usr/bin/env bash
PROJECT_ID="TU_GCP_PROJECT"           # ← reemplaza
DATASET="sha713_audit"
TABLE="gh_archive_watch"
bq query --use_legacy_sql=false --format=csv "
  INSERT INTO \`${PROJECT_ID}.${DATASET}.${TABLE}\` (snapshot_ts, event_type, actor_login)
  SELECT created_at, type, actor.login
  FROM \`githubarchive.month.*\`
  WHERE _TABLE_SUFFIX = FORMAT_DATE('%Y%m', DATE_SUB(CURRENT_DATE(), INTERVAL 1 MONTH))
    AND repo.name = 'gkfsupra/sha713-factory'
    AND type IN ('WatchEvent','ForkEvent')
    AND created_at > TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL 3 HOUR);
"
BASH
  chmod +x monitor.sh
  (crontab -l 2>/dev/null; echo "0 */3 * * * $(pwd)/monitor.sh") | crontab -
  echo "🜂 Hawk-BQ activado – vigilia cada 3 h"
fi

echo "🜂 PULSO COMPLETADO – Legado blindado y en vigilancia. Avanti."
