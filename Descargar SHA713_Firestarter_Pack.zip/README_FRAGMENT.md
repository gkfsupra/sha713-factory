### SHA-713 • Badge / Signature

Embed (README):
```md
![713 Verified](./assets/713-verified.svg)

Giankoof · SHA-713 · GKF IA™ — “No te traiciones.”
```
