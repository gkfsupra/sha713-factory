#!/usr/bin/env python3
"""
make_qr_utm.py — genera QR por canal con UTM.
Requiere: pip install qrcode[pil]
Uso:
  python3 make_qr_utm.py --base https://gkfsupra.github.io/sha713-factory/ --channels linkedin twitter email github --out ./assets/qr/
"""
import argparse, os
try:
    import qrcode  # pip install qrcode[pil]
except Exception as e:
    print("Instala dependencia: pip install qrcode[pil]")
    raise

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--base", required=True, help="URL base (ej: https://gkfsupra.github.io/sha713-factory/)")
    ap.add_argument("--channels", nargs="+", required=True, help="Lista de canales (ej: linkedin email twitter)")
    ap.add_argument("--out", default="./qr_out/", help="Carpeta de salida")
    args = ap.parse_args()

    os.makedirs(args.out, exist_ok=True)
    for ch in args.channels:
        url = f"{args.base}?utm_source={ch}"
        img = qrcode.make(url)
        path = os.path.join(args.out, f"qr_{ch}.png")
        img.save(path)
        print("QR generado:", path, "→", url)

if __name__ == "__main__":
    main()
