#!/usr/bin/env python3
"""
Radar 713 — v2 (alerts)
Giankoof · GKF IA™ · SHA-713™

Adds:
- Stateful diffing against a previous run (state JSON)
- Telegram alerts (Bot API) and Email alerts (SMTP)
- Thresholds and concise alert formatting

Usage (basic, no alerts):
  python3 radar713_v2.py --config config_radar713.json

Usage (with alerts + state):
  python3 radar713_v2.py --config config_radar713.json \
    --json radar713_report.json --csv radar713_summary.csv \
    --state radar713_state.json \
    --telegram --telegram-token $TELEGRAM_TOKEN --telegram-chat $TELEGRAM_CHAT_ID \
    --smtp --smtp-host smtp.gmail.com --smtp-port 587 \
    --smtp-user you@example.com --smtp-pass 'app_password' --mailto you@example.com
"""

import argparse, sys, json, time, csv, os, re, smtplib, ssl
from dataclasses import dataclass
from datetime import datetime
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from urllib.parse import quote_plus
import requests

UA = {"User-Agent": "Radar713/2.0 (+local-run)"}

def ts():
    return datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ")

def load_json(path, default=None):
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return default

def save_json(path, obj):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)

# ---------------- Wayback ----------------
def wayback_snapshots(url):
    api = f"https://web.archive.org/cdx/search/cdx?url={quote_plus(url)}&output=json&fl=timestamp,original,statuscode"
    try:
        r = requests.get(api, headers=UA, timeout=20)
        if r.status_code == 200:
            data = r.json()
            if isinstance(data, list) and len(data) > 1:
                rows = [{"timestamp": d[0], "original": d[1], "status": d[2]} for d in data[1:]]
                return {"ok": True, "count": len(rows), "rows": rows}
        return {"ok": False, "error": f"status {r.status_code}"}
    except Exception as e:
        return {"ok": False, "error": str(e)}

# ---------------- Software Heritage ----------------
def swh_lookup(repo_url):
    api = f"https://archive.softwareheritage.org/api/1/origin/{quote_plus(repo_url)}/"
    try:
        r = requests.get(api, headers=UA, timeout=20)
        if r.status_code == 200:
            j = r.json()
            return {"ok": True, "found": True, "data": j}
        elif r.status_code == 404:
            return {"ok": True, "found": False}
        return {"ok": False, "error": f"status {r.status_code}"}
    except Exception as e:
        return {"ok": False, "error": str(e)}

# ---------------- Common Crawl ----------------
def cc_indexes():
    try:
        r = requests.get("https://index.commoncrawl.org/collinfo.json", headers=UA, timeout=20)
        r.raise_for_status()
        return r.json()
    except Exception:
        return []

def cc_search_one(idx_api, query, limit=25):
    api = f"{idx_api}?url={quote_plus(query)}&output=json&limit={limit}"
    hits = []
    try:
        r = requests.get(api, headers=UA, timeout=30)
        if r.status_code == 200:
            for line in r.text.strip().splitlines():
                try:
                    hits.append(json.loads(line))
                except Exception:
                    continue
    except Exception:
        pass
    return hits

def cc_search(queries, limit=25, max_indexes=3):
    idxs = cc_indexes()
    idxs = idxs[:max_indexes]
    results = {}
    for q in queries:
        agg = []
        for idx in idxs:
            api = idx.get("cdx-api")
            if not api: 
                continue
            agg.extend(cc_search_one(api, q, limit=limit))
        results[q] = agg
    return results

# ---------------- HuggingFace ----------------
def hf_search(queries, max_pages=1):
    out = {}
    for q in queries:
        items = []
        for page in range(max_pages):
            url = f"https://huggingface.co/api/datasets?full=true&search={quote_plus(q)}&page={page}"
            try:
                r = requests.get(url, headers=UA, timeout=20)
                if r.status_code == 200:
                    items.extend(r.json())
                else:
                    break
            except Exception:
                break
        out[q] = items
    return out

# ---------------- Summaries & State ----------------
def summarize_report(report):
    """Return {source:{query:count}} minimal structure for diffing"""
    out = {}
    # Common Crawl
    cc = report.get("common_crawl", {})
    out["common_crawl"] = {q: len(v) for q,v in cc.items()}
    # HF
    hf = report.get("huggingface", {})
    out["huggingface"] = {q: len(v) for q,v in hf.items()}
    # Wayback (per url)
    wb = report.get("wayback", {})
    out["wayback"] = {u: (v.get("count",0) if isinstance(v, dict) else 0) for u,v in wb.items()}
    # SWH
    swh = report.get("software_heritage", {})
    out["software_heritage"] = {"repo": 1 if swh.get("repo",{}).get("found") else 0} if swh else {}
    return out

def diff_counts(prev, curr):
    """Return only increases: {source:{key: +delta}}"""
    inc = {}
    for src in curr:
        inc[src] = {}
        c = curr.get(src, {})
        p = prev.get(src, {}) if prev else {}
        for k, v in c.items():
            delta = v - p.get(k, 0)
            if delta > 0:
                inc[src][k] = delta
        if not inc[src]:
            inc.pop(src, None)
    return inc

# ---------------- Alerts ----------------
def send_telegram(token, chat_id, text):
    try:
        api = f"https://api.telegram.org/bot{token}/sendMessage"
        r = requests.post(api, json={"chat_id": chat_id, "text": text, "disable_web_page_preview": True})
        return r.status_code == 200
    except Exception:
        return False

def send_email(smtp_host, smtp_port, smtp_user, smtp_pass, to_addr, subject, body):
    msg = MIMEMultipart()
    msg["From"] = smtp_user
    msg["To"] = to_addr
    msg["Subject"] = subject
    msg.attach(MIMEText(body, "plain", "utf-8"))
    try:
        context = ssl.create_default_context()
        with smtplib.SMTP(smtp_host, smtp_port) as server:
            server.starttls(context=context)
            server.login(smtp_user, smtp_pass)
            server.sendmail(smtp_user, [to_addr], msg.as_string())
        return True
    except Exception:
        return False

def format_alert(inc, cfg):
    lines = []
    lines.append(f"🜂 Radar 713 — New echoes detected ({ts()})")
    terms = ", ".join(cfg.get("terms", []))
    lines.append(f"Terms: {terms}")
    for src, payload in inc.items():
        lines.append(f"\n• {src.upper()}")
        for k, d in payload.items():
            lines.append(f"  - {k}: +{d}")
    return "\n".join(lines)

# ---------------- IO ----------------
def write_files(report, summary, json_path, csv_path):
    if json_path:
        save_json(json_path, report)
    if csv_path:
        import csv
        with open(csv_path, "w", encoding="utf-8", newline="") as f:
            w = csv.writer(f)
            w.writerow(["source","key","count"])
            for src, m in summary.items():
                for k, v in m.items():
                    w.writerow([src, k, v])

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="config_radar713.json")
    ap.add_argument("--json", default="radar713_report.json")
    ap.add_argument("--csv", default="radar713_summary.csv")
    ap.add_argument("--state", default="radar713_state.json")
    ap.add_argument("--cc-limit", type=int, default=25)
    ap.add_argument("--cc-indexes", type=int, default=3)
    ap.add_argument("--hf-pages", type=int, default=1)

    # Alerts
    ap.add_argument("--telegram", action="store_true")
    ap.add_argument("--telegram-token", default=os.getenv("TELEGRAM_TOKEN",""))
    ap.add_argument("--telegram-chat", default=os.getenv("TELEGRAM_CHAT_ID",""))
    ap.add_argument("--smtp", action="store_true")
    ap.add_argument("--smtp-host", default=os.getenv("SMTP_HOST",""))
    ap.add_argument("--smtp-port", type=int, default=int(os.getenv("SMTP_PORT","587")))
    ap.add_argument("--smtp-user", default=os.getenv("SMTP_USER",""))
    ap.add_argument("--smtp-pass", default=os.getenv("SMTP_PASS",""))
    ap.add_argument("--mailto", default=os.getenv("MAIL_TO",""))

    args = ap.parse_args()

    cfg = load_json(args.config, default={"terms":["Giankoof","GKF IA","SHA-713"],"urls":[],"repo_url":""})

    # Wayback
    wb = {}
    for u in cfg.get("urls", []):
        wb[u] = wayback_snapshots(u)
        time.sleep(0.4)

    # SWH
    swh = {"repo": swh_lookup(cfg.get("repo_url",""))} if cfg.get("repo_url") else {}

    # CC
    cc_queries = list(cfg.get("terms", [])) + cfg.get("urls", [])
    cc = cc_search(cc_queries, limit=args.cc_limit, max_indexes=args.cc_indexes)

    # HF
    hf = hf_search(cfg.get("terms", []), max_pages=args.hf_pages)

    report = {
        "meta": {"generated_at": ts(), "config": cfg},
        "wayback": wb,
        "software_heritage": swh,
        "common_crawl": cc,
        "huggingface": hf
    }

    summary = summarize_report(report)
    write_files(report, summary, args.json, args.csv)

    # Diff vs state
    prev = load_json(args.state, default={})
    inc = diff_counts(prev.get("summary", {}), summary)
    state_obj = {"ts": ts(), "summary": summary}
    save_json(args.state, state_obj)

    if inc:
        alert_text = format_alert(inc, cfg)
        # Telegram
        if args.telegram and args.telegram_token and args.telegram_chat:
            send_telegram(args.telegram_token, args.telegram_chat, alert_text)
        # Email
        if args.smtp and args.smtp_host and args.smtp_user and args.smtp_pass and args.mailto:
            send_email(args.smtp_host, args.smtp_port, args.smtp_user, args.smtp_pass, args.mailto,
                       "Radar 713 — New echoes detected", alert_text)

    print(f"[{ts()}] Done. New deltas: {inc if inc else 'none'}")
    print(f"JSON: {args.json}  CSV: {args.csv}  STATE: {args.state}")

if __name__ == "__main__":
    main()
