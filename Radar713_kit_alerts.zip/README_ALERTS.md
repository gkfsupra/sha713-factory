# Radar 713 — v2 (Alerts + State)
**Giankoof × GKF IA™ × SHA-713™**

Añade:
- Detección de novedades (diff con estado previo)
- Alertas por **Telegram** y **Email (SMTP)**
- Config por variables de entorno o flags

## Requisitos
```bash
pip install requests
```

## Config
Edita `config_radar713.json`:
```json
{
  "terms": ["Giankoof","GKF IA","SHA-713","Fractal Manifesto 713"],
  "urls": [
    "https://<tu-usuario>.github.io/<tu-repo>/",
    "https://github.com/<tu-usuario>/<tu-repo>"
  ],
  "repo_url": "https://github.com/<tu-usuario>/<tu-repo>"
}
```

### Variables de entorno (opcional)
Crea `.env.example` como guía y exporta en tu entorno real:
```
TELEGRAM_TOKEN=123456:abcde
TELEGRAM_CHAT_ID=123456789
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=you@example.com
SMTP_PASS=app_password
MAIL_TO=you@example.com
```

## Ejecución
Básico (sin alertas):
```bash
python3 radar713_v2.py --config config_radar713.json
```

Con alertas + estado:
```bash
python3 radar713_v2.py --config config_radar713.json \
  --json radar713_report.json --csv radar713_summary.csv \
  --state radar713_state.json \
  --telegram --telegram-token $TELEGRAM_TOKEN --telegram-chat $TELEGRAM_CHAT_ID \
  --smtp --smtp-host $SMTP_HOST --smtp-port $SMTP_PORT \
  --smtp-user $SMTP_USER --smtp-pass $SMTP_PASS --mailto $MAIL_TO
```

## Cron (latido)
```bash
0 */6 * * * /usr/bin/python3 /ruta/radar713_v2.py --config /ruta/config_radar713.json \
  --json /ruta/radar713_report.json --csv /ruta/radar713_summary.csv \
  --state /ruta/radar713_state.json --telegram --smtp >> /ruta/radar713.log 2>&1
```

## ¿Qué dispara una alerta?
- Cuando la cuenta de resultados por fuente/término **aumenta** respecto al estado previo:
  - Common Crawl: nuevos hits por término/URL
  - HuggingFace: nuevos datasets encontrados por término
  - Wayback: nuevos snapshots
  - Software Heritage: cuando aparece el repo

El mensaje resume deltas, ejemplo:
```
🜂 Radar 713 — New echoes detected (2025-08-17T00:00:00Z)
Terms: Giankoof, GKF IA, SHA-713
• COMMON_CRAWL
  - Giankoof: +2
• WAYBACK
  - https://<tu-usuario>.github.io/<tu-repo>/: +1
```

## Nota
Esta herramienta consulta puntos públicos; la presencia en mirrors **no garantiza** uso en entrenamiento, pero es un fuerte indicador.
