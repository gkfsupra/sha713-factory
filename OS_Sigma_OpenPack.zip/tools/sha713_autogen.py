#!/usr/bin/env python3
import os, json, hashlib, base64, time, pathlib
from datetime import datetime, timezone

ROOT = pathlib.Path(__file__).resolve().parents[1]
DROPS = ROOT / "drops"
TOKENS = ROOT / "tokens" / "tokens.json"
AUTO = ROOT / "site" / "auto"

def sha256_hex(b): return hashlib.sha256(b).hexdigest()

def make_token(b, subject, author):
    h0 = sha256_hex(b)
    nonce = os.urandom(16).hex()
    h1 = hashlib.sha256(bytes.fromhex(h0)+bytes.fromhex(nonce)).hexdigest()
    h2 = hashlib.sha256(bytes.fromhex(h1)+author.encode()).hexdigest()
    tok = {
        "type":"sha713-token","version":"713.2-os-sigma","token_id":h2[:32],
        "timestamp_utc": datetime.now(timezone.utc).isoformat(),
        "subject": subject, "author": author, "content_sha256": h0, "nonce_hex": nonce,
        "hash_chain":{"h0":h0,"h1":h1,"h2":h2}
    }
    compact = "sha713://" + base64.urlsafe_b64encode(json.dumps(tok,separators=(',',':')).encode()).decode().rstrip("=")
    return tok, compact

def load_json(p, default):
    if not p.exists(): p.parent.mkdir(parents=True,exist_ok=True); p.write_text(json.dumps(default,indent=2),encoding='utf-8')
    return json.loads(p.read_text(encoding='utf-8'))

def write(p, s):
    p.parent.mkdir(parents=True,exist_ok=True); p.write_text(s, encoding='utf-8')

def main():
    author = os.environ.get("SHA713_AUTHOR","OS‑Σ")
    tokens = load_json(TOKENS, [])
    known = {t.get("content_sha256","") for t in tokens}
    minted=0
    for fp in DROPS.glob("*"):
        if not fp.is_file(): continue
        b = fp.read_bytes()
        h0 = sha256_hex(b)
        if h0 in known: print("[skip]", fp.name); continue
        tok, uri = make_token(b, fp.stem, author)
        dest = AUTO / fp.stem; dest.mkdir(parents=True,exist_ok=True)
        (dest/"payload.bin").write_bytes(b)
        write(dest/"token.json", json.dumps(tok, indent=2))
        write(dest/"uri.txt", uri)
        tokens.append({"token_id":tok["token_id"],"subject":fp.stem,"content_sha256":tok["content_sha256"],"timestamp_utc":tok["timestamp_utc"],"uri":uri})
        minted+=1; print("[minted]", fp.name)
    write(TOKENS, json.dumps(tokens, indent=2))
    print("[done] minted:", minted)

if __name__ == "__main__":
    main()
