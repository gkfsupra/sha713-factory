#!/usr/bin/env python3
import json, sys
from datetime import datetime, timezone

def load(p): 
    with open(p,'r',encoding='utf-8') as f: return json.load(f)

def save(p, obj):
    with open(p,'w',encoding='utf-8') as f: json.dump(obj,f,ensure_ascii=False,indent=2)

def score(evt, rules, now=None):
    from datetime import datetime, timezone
    if now is None: now = datetime.now(timezone.utc)
    rt = rules["events"].get(evt["type"])
    if not rt: return 0.0
    s = float(rt.get("base",0))
    mul = rt.get("multipliers",{})
    for k,v in (evt.get("weights") or {}).items():
        if k in mul: s += float(mul[k])*float(v)
    # decay
    ts = datetime.fromisoformat(evt.get("timestamp_utc"))
    hl = float(rules.get("decay",{}).get("half_life_days",180))
    if hl>0:
        days=(now-ts).total_seconds()/86400.0
        s *= (0.5 ** (days/hl))
    return s

def main(ledger_path, rules_path, out_path):
    rules = load(rules_path); ledger = load(ledger_path)
    bal = {}
    now = datetime.now(timezone.utc)
    for evt in ledger.get("events",[]):
        a = evt["actor"]; bal[a] = bal.get(a,0.0) + score(evt, rules, now=now)
    save(out_path, bal); print("[balances] written:", out_path)

if __name__ == "__main__":
    args=sys.argv[1:]
    if len(args)<3: 
        print("usage: siat_compute.py ledger.json rules.json balances.json"); sys.exit(1)
    main(args[0], args[1], args[2])
