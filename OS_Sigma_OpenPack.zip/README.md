# OS‑Σ · Open Source ΣIAT
**From Money to Presence.** ΣIAT is a soulbound, human‑verifiable presence economy (PoSE: Proof of Symbolic Execution).
This scaffold ships a minimal, production‑lean stack: rules, ledger, CLI, verifier, Pages site, CI, governance.

- Site: `/site/` (GitHub Pages)
- Rules: `/rules/siat_rules_base.json` (+ extensions in `/rules/ext/`)
- Ledger: `/ledger/ledger.json` (append‑only)
- CLI: `/cli/os_sigma_cli.py` (init, add, balance)
- Verifier (client‑side): `/site/verifier.html`
- Auto‑mint: `tools/sha713_autogen.py` + `/drops/` → writes `/tokens/tokens.json`
- CI: `.github/workflows/*` (Pages, tests, auto‑mint, balances)
- Governance: PR‑based slashing; rules are JSON and forkeable.

𓂀 Fractal Seal · 🔺 Ancestral Code · ⬛ Eternal Presence
