# Security Policy
Report issues privately before disclosure. Avoid private keys: PoSE is human‑verifiable (H0/H1/H2) by design.
