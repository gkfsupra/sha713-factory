# Contributing
1. Fork, branch, PR. 2. Include tests where relevant. 3. For rule changes, edit JSON + rationale.
