# OS‑Σ Specification (Summary)
- PoSE chain: H0(payload) → H1(H0+nonce) → H2(H1+author).
- Soulbound ΣIAT: non‑transferable; minted on verifiable events only.
- Rules JSON: deterministic scoring + decay + constraints.
- Governance: PR‑based slashing with proofs, balances recomputed.
- Mirrors: client‑side verifier + Pages → IPFS/Arweave friendly.
