# Code of Conduct
Be excellent to each other. Act with integrity, curiosity, and respect. Zero tolerance for harassment.
