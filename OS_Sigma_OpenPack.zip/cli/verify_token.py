#!/usr/bin/env python3
import json, sys, hashlib

def h(b): return hashlib.sha256(b).hexdigest()

def main(token_path, content_path=None):
    tok = json.load(open(token_path,'r',encoding='utf-8'))
    ok0="n/a"
    if content_path:
        payload = open(content_path,'rb').read()
        ok0 = (h(payload) == tok["content_sha256"])
    h1 = h(bytes.fromhex(tok["hash_chain"]["h0"]) + bytes.fromhex(tok["nonce_hex"]))
    h2 = h(bytes.fromhex(h1) + tok["author"].encode("utf-8"))
    print("H0 match:", ok0)
    print("H1 match:", h1 == tok["hash_chain"]["h1"])
    print("H2 match:", h2 == tok["hash_chain"]["h2"])
    print("Token ID:", tok["token_id"])

if __name__ == "__main__":
    args=sys.argv[1:]
    if not args: 
        print("usage: verify_token.py token.json [payload]"); sys.exit(1)
    main(args[0], args[1] if len(args)>1 else None)
