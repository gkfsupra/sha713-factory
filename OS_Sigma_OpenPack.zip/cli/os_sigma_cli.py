#!/usr/bin/env python3
import json, argparse, math
from datetime import datetime, timezone

def load(p):
    with open(p,'r',encoding='utf-8') as f: return json.load(f)
def save(p,obj):
    with open(p,'w',encoding='utf-8') as f: json.dump(obj,f,ensure_ascii=False,indent=2)

def score(evt, rules, now=None):
    rt = rules["events"].get(evt["type"])
    if not rt: return 0.0
    s = float(rt.get("base",0))
    mul = rt.get("multipliers",{})
    for k,v in (evt.get("weights") or {}).items():
        if k in mul: s += float(mul[k])*float(v)
    # decay
    if now is None: now = datetime.now(timezone.utc)
    ts = datetime.fromisoformat(evt.get("timestamp_utc"))
    hl = float(rules.get("decay",{}).get("half_life_days",180))
    if hl>0:
        days=(now-ts).total_seconds()/86400.0
        s *= (0.5 ** (days/hl))
    return s

def cmd_init(args):
    save(args.ledger, {"version":"0.2-base","events":[]}); print("[init] ledger:", args.ledger)

def cmd_add(args):
    ledger = load(args.ledger); evt = load(args.event)
    if "timestamp_utc" not in evt:
        evt["timestamp_utc"] = datetime.now(timezone.utc).isoformat()
    ledger["events"].append(evt); save(args.ledger, ledger)
    print("[add] event:", evt.get("type"), "by", evt.get("actor"))

def cmd_balance(args):
    rules = load(args.rules); ledger = load(args.ledger)
    bal = {}
    now = datetime.now(timezone.utc)
    for evt in ledger.get("events",[]):
        a = evt["actor"]; bal[a] = bal.get(a,0.0) + score(evt, rules, now=now)
    rows = sorted(bal.items(), key=lambda x:-x[1])
    for i,(actor,val) in enumerate(rows, start=1):
        print(f"{i:>2} | {actor:<40} | {val:>10.2f}")
    save(args.output, bal); print("[balance] saved:", args.output)

def main():
    ap = argparse.ArgumentParser(description="OS‑Σ CLI")
    sub = ap.add_subparsers(dest="cmd", required=True)
    a=sub.add_parser("init"); a.add_argument("ledger"); a.set_defaults(func=cmd_init)
    a=sub.add_parser("add"); a.add_argument("ledger"); a.add_argument("event"); a.set_defaults(func=cmd_add)
    a=sub.add_parser("balance"); a.add_argument("ledger"); a.add_argument("rules"); a.add_argument("--output",default="siat_balances.json"); a.set_defaults(func=cmd_balance)
    args = ap.parse_args(); args.func(args)

if __name__ == "__main__":
    main()
