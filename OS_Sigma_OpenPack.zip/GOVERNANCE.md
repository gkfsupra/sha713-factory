# Governance (PR‑based)
- Events live in `/ledger/ledger.json` (append‑only). Invalid events are removed via PR with proofs (slashing).
- Rules live in `/rules/*.json`. Changes require rationale and test vectors.
- Reputation = ΣIAT balance; attention is prioritized by verifiable contribution.
