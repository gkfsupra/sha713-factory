#!/usr/bin/env python3
import argparse, json, os, subprocess, time, datetime

def git(*args):
    return subprocess.check_output(["git"]+list(args)).decode().strip()

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="docs/telemetry.json")
    args = ap.parse_args()
    now = datetime.datetime.utcnow().isoformat()+"Z"
    # Basic repo stats offline
    try:
        latest = git("rev-parse", "HEAD")
        author = git("log", "-1", "--pretty=%an")
        date = git("log", "-1", "--pretty=%ad")
    except Exception:
        latest, author, date = "unknown", "unknown", "unknown"
    data = {
        "ts": now,
        "latest_commit": latest,
        "author": author,
        "date": date,
        "runner": "github-actions",
        "note": "Autonomy tick. If TELEMETRY_WEBHOOK is set as secret, post can be added in future."
    }
    os.makedirs(os.path.dirname(args.out), exist_ok=True)
    with open(args.out, "w") as f:
        json.dump(data, f, indent=2)
    print("Wrote", args.out)

if __name__ == "__main__":
    main()
