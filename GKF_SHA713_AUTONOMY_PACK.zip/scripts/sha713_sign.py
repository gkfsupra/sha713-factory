#!/usr/bin/env python3
import argparse, hashlib, os, sys, json

EXCLUDES = {".git", ".github", "__pycache__", "site"}

def iter_files(base):
    for root, dirs, files in os.walk(base):
        # prune excludes
        dirs[:] = [d for d in dirs if d not in EXCLUDES]
        for f in files:
            if f.endswith(('.png','.jpg','.jpeg','.zip','.tar','.gz','.webp')):
                # include binary too but it's fine; skip large archives if needed
                pass
            path = os.path.join(root, f)
            rel = os.path.relpath(path, base)
            yield rel, path

def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1024*1024), b""):
            h.update(chunk)
    return h.hexdigest()

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="docs/SHA713_SIGNATURE.txt")
    args = ap.parse_args()
    base = os.getcwd()
    chain = []
    for rel, path in sorted(iter_files(base)):
        digest = sha256(path)
        chain.append({"path": rel, "sha256": digest})
    # chain hash
    h = hashlib.sha256()
    for item in chain:
        h.update(item["sha256"].encode())
    salt = os.environ.get("SHA713_SALT", "")
    h.update(salt.encode())
    final = h.hexdigest()
    os.makedirs(os.path.dirname(args.out), exist_ok=True)
    with open(args.out, "w") as fp:
        fp.write("SHA-713 signature (chained SHA-256)\n")
        fp.write(f"root: {final}\n")
        for item in chain:
            fp.write(f"{item['sha256']}  {item['path']}\n")
    print("SHA-713 root:", final)

if __name__ == "__main__":
    sys.exit(main())
