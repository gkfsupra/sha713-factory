# Security Policy
Please report vulnerabilities via private email or security advisory. Do not open public issues for sensitive reports.
