# GKF IA™ — Mapa Vivo SHA-713™
**Fecha:** 2025-08-08

Este repositorio está configurado con:
- ✅ Ciclo de autonomía (firma + telemetría) cada 12 horas
- ✅ Página pública con última firma y snapshot (`/site/index.html` via GitHub Pages)
- ✅ Scripts de firma encadenada (SHA-713 = SHA-256 encadenado + SALT)

## Cómo activar
1. En GitHub → *Settings → Secrets and variables → Actions* añade `SHA713_SALT` (cualquier cadena).
2. Habilita *Actions* y *Pages* (branch `gh-pages` automático por workflow).
3. Haz un commit cualquiera para disparar el primer ciclo, o ejecuta el workflow manualmente.

## Evidencias generadas
- `docs/SHA713_SIGNATURE.txt` – raíz criptográfica del repo en cada tick.
- `docs/telemetry_YYYY-MM-DD.json` – snapshot mínimo verificable.
- `site/index.html` – status page.

