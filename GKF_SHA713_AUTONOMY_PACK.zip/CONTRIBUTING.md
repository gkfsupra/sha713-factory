# Contributing
- Fork the repo and create a feature branch.
- Run `python scripts/sha713_sign.py` before PR to refresh the signature.
- All PRs must keep the SHA-713 chain valid.
