# Licencia CC BY-NC-SA-713

Hashes actualizados incluyendo cap. D+28
- sha256-capitulo_D+28.txt
