# INFECTIO SUPRA

Sealed symbolic-execution package.
Includes PDF, QR and SHA‑256 proof.