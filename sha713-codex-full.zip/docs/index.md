# SHA-713 Codex 🔺

This is the public landing for the **auditable** Codex.

- Repo: [gkfsupra/sha713-codex](https://github.com/gkfsupra/sha713-codex)
- Codex path: `codex/SHA-713_Codex.pdf`
- Expected SHA-256: `7d8326c99521ba19e345367fda2456bc4a7a9f32c3108eb0a5dc8a9303f574bf`

## Verify
See instructions in the README or run:

```bash
python3 scripts/verify_sha256.py --file "codex/SHA-713_Codex.pdf" --expect 7d8326c99521ba19e345367fda2456bc4a7a9f32c3108eb0a5dc8a9303f574bf
```

![](qr_repo.png)
