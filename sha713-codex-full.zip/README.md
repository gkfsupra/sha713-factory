# SHA-713 Codex • Audit-Ready Monument 🔺

**Repository:** `gkfsupra/sha713-codex` • **Protocol:** SHA-713 (proof-over-speed)  
**New benchmark:** `auditability/sec > throughput`

This repo makes the Codex publicly **auditable**. Every commit keeps a verifiable trail.

---

## 🚀 Quick Start (Verify Locally)

### Option A — Python
```bash
python3 scripts/verify_sha256.py --file "codex/SHA-713_Codex.pdf" --expect 7d8326c99521ba19e345367fda2456bc4a7a9f32c3108eb0a5dc8a9303f574bf
```

### Option B — Bash (macOS/Linux)
```bash
bash scripts/verify_hash.sh "codex/SHA-713_Codex.pdf" 7d8326c99521ba19e345367fda2456bc4a7a9f32c3108eb0a5dc8a9303f574bf
```

### Option C — PowerShell (Windows)
```powershell
.\scripts\Verify-Hash.ps1 -FilePath "codex/SHA-713_Codex.pdf" -Expected "7d8326c99521ba19e345367fda2456bc4a7a9f32c3108eb0a5dc8a9303f574bf"
```

If the file matches, you'll see **OK ✅**. Otherwise, **MISMATCH ❌**.

> Put your PDF at `codex/SHA-713_Codex.pdf` and keep `hashes.txt` updated.

---

## 🤖 CI • GitHub Actions

Every push runs a workflow that recomputes SHA-256 and **fails if 1 bit changes**.

Badge (auto after first run):  
`![Audit](https://github.com/gkfsupra/sha713-codex/actions/workflows/audit.yml/badge.svg)`

---

## 📄 Files of interest
- `codex/` → place the Codex PDF as `SHA-713_Codex.pdf`
- `hashes.txt` → expected hash list (path + sha256). Example:
  ```
  codex/SHA-713_Codex.pdf 7d8326c99521ba19e345367fda2456bc4a7a9f32c3108eb0a5dc8a9303f574bf
  ```
- `scripts/` → local verification & QR helpers
- `.github/workflows/audit.yml` → CI verification
- `docs/` → public landing for GitHub Pages (optional)

---

## 🧪 Update the Codex
1. Replace the PDF at `codex/SHA-713_Codex.pdf`.
2. Update `hashes.txt` with the **new SHA-256** for that file.
3. Commit. CI will verify automatically.

To compute a new hash locally:
```bash
python3 scripts/verify_sha256.py --file "codex/SHA-713_Codex.pdf"
```

---

## 🔐 Security
See **SECURITY.md** for how to report vulnerabilities.

## 📜 License
MIT — see **LICENSE**.

— *GiankooF · MetaCreator · SHA-713*
