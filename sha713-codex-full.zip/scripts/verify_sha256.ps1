param(
  [Parameter(Mandatory=$true)][string]$File,
  [Parameter(Mandatory=$true)][string]$Expect
)

$hash = (Get-FileHash -Path $File -Algorithm SHA256).Hash.ToLower()
Write-Host "File: $File"
Write-Host "SHA-256: $hash"
Write-Host "Expected: $Expect"
if ($hash -eq $Expect.ToLower()) { Write-Host "RESULT: OK ✅"; exit 0 }
else { Write-Host "RESULT: MISMATCH ❌"; exit 2 }
