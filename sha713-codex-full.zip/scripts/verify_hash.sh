#!/usr/bin/env bash
# Verify SHA-256 using system shasum/sha256sum
set -euo pipefail
FILE="${1:-codex/SHA-713_Codex.pdf}"
EXPECTED="${2:-7d8326c99521ba19e345367fda2456bc4a7a9f32c3108eb0a5dc8a9303f574bf}"

if command -v shasum >/dev/null 2>&1; then
  ACTUAL="$(shasum -a 256 "$FILE" | awk '{print $1}')"
elif command -v sha256sum >/dev/null 2>&1; then
  ACTUAL="$(sha256sum "$FILE" | awk '{print $1}')"
else
  echo "No sha256 tool found." ; exit 2
fi

echo "File: $FILE"
echo "SHA-256:   $ACTUAL"
echo "Expected:  $EXPECTED"
if [ "$ACTUAL" = "$EXPECTED" ]; then
  echo "RESULT: OK ✅"
  exit 0
else
  echo "RESULT: MISMATCH ❌"
  exit 2
fi
