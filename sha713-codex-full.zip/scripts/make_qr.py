#!/usr/bin/env python3
# Generate simple QR codes for repo & docs
import qrcode
qr_repo = qrcode.make("https://github.com/gkfsupra/sha713-codex")
qr_repo.save("docs/qr_repo.png")
qr_docs = qrcode.make("https://github.com/gkfsupra/sha713-codex/tree/main/docs")
qr_docs.save("docs/qr_docs.png")
print("Generated docs/qr_repo.png and docs/qr_docs.png")
