#!/usr/bin/env bash
set -euo pipefail
FILE="${1:-SHA-713_Codex_Giankoof.pdf}"
EXPECT="7d8326c99521ba19e345367fda2456bc4a7a9f32c3108eb0a5dc8a9303f574bf"
ACTUAL="$(shasum -a 256 "$FILE" | awk '{print $1}')"
echo "File:   $FILE"
echo "SHA256: $ACTUAL"
echo "Expect: $EXPECT"
test "$ACTUAL" = "$EXPECT" && echo "RESULT: OK ✅" || { echo "RESULT: MISMATCH ❌"; exit 2; }
