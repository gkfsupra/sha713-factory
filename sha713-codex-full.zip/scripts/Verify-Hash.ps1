Param(
  [Parameter(Mandatory=$true)] [string]$FilePath,
  [Parameter(Mandatory=$true)] [string]$Expected
)
$bytes = [System.IO.File]::ReadAllBytes($FilePath)
$sha256 = [System.Security.Cryptography.SHA256]::Create()
$digest = ($sha256.ComputeHash($bytes) | ForEach-Object { $_.ToString("x2") }) -join ""
Write-Output "File: $FilePath"
Write-Output "SHA-256:   $digest"
Write-Output "Expected:  $Expected"
if ($digest.ToLower() -eq $Expected.ToLower()) {
  Write-Output "RESULT: OK ✅"; exit 0
} else {
  Write-Output "RESULT: MISMATCH ❌"; exit 2
}
