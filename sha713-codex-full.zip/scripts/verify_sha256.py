#!/usr/bin/env python3
import argparse, hashlib, pathlib, sys

def sha256_file(path: pathlib.Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            h.update(chunk)
    return h.hexdigest()

def verify_single(path: pathlib.Path, expected: str) -> bool:
    digest = sha256_file(path)
    print(f"File: {path}")
    print(f"SHA-256:   {digest}")
    print(f"Expected:  {expected}")
    ok = (digest.lower() == expected.lower())
    print("RESULT:", "OK ✅" if ok else "MISMATCH ❌")
    return ok

def verify_from_hashes(hash_file: pathlib.Path) -> bool:
    ok_all = True
    for line in hash_file.read_text().splitlines():
        line = line.strip()
        if not line or line.startswith("#"): 
            continue
        try:
            path_str, expected = line.split()
        except ValueError:
            print(f"Invalid line in {hash_file}: {line}")
            ok_all = False
            continue
        path = pathlib.Path(path_str)
        if not path.exists():
            print(f"Missing file: {path_str} ❌")
            ok_all = False
            continue
        if not verify_single(path, expected):
            ok_all = False
    return ok_all

if __name__ == "__main__":
    p = argparse.ArgumentParser(description="Verify SHA-256 of a file or a hashes list")
    p.add_argument("--file", help="Path to a single file to verify")
    p.add_argument("--expect", help="Expected SHA-256 (hex) for --file")
    p.add_argument("--hashes", help="Path to hashes list (default: hashes.txt)", default="hashes.txt")
    p.add_argument("--fail-on-mismatch", action="store_true", help="Exit non-zero on mismatch")
    args = p.parse_args()

    ok = True
    if args.file:
        if not args.expect:
            # If no expected value is given, just print the digest
            path = pathlib.Path(args.file)
            if not path.exists():
                print(f"File not found: {path}")
                sys.exit(2)
            digest = sha256_file(path)
            print(digest)
            sys.exit(0)
        ok = verify_single(pathlib.Path(args.file), args.expect)
    else:
        ok = verify_from_hashes(pathlib.Path(args.hashes))

    sys.exit(0 if (ok or not args.fail_on_mismatch) else 2)
