# Security Policy

If you discover a security issue affecting this repository or the Codex artifacts,
please email **security@gkf-ia.org** (PGP available upon request).

- Give as much detail as possible (steps, environment, logs).
- We aim to acknowledge within 72 hours.
