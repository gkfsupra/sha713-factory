## Summary
Explain what this PR changes.

## Checklist
- [ ] Updated `hashes.txt` if Codex PDF changed
- [ ] `scripts/verify_sha256.py` passes locally
- [ ] CI audit passes
