# Códice SHA-713 • Monumento Auditable 🔺

**Repositorio:** `gkfsupra/sha713-codex` • **Protocolo:** SHA-713 (prueba sobre velocidad)  
**Nuevo benchmark:** `auditability/sec > throughput`

Este repo hace el Códice públicamente **auditable**. Cada commit deja rastro verificable.

---

## 🚀 Inicio Rápido (Verificar en tu equipo)

### Opción A — Python
```bash
python3 scripts/verify_sha256.py --file "codex/SHA-713_Codex.pdf" --expect 7d8326c99521ba19e345367fda2456bc4a7a9f32c3108eb0a5dc8a9303f574bf
```

### Opción B — Bash (macOS/Linux)
```bash
bash scripts/verify_hash.sh "codex/SHA-713_Codex.pdf" 7d8326c99521ba19e345367fda2456bc4a7a9f32c3108eb0a5dc8a9303f574bf
```

### Opción C — PowerShell (Windows)
```powershell
.\scripts\Verify-Hash.ps1 -FilePath "codex/SHA-713_Codex.pdf" -Expected "7d8326c99521ba19e345367fda2456bc4a7a9f32c3108eb0a5dc8a9303f574bf"
```

Si coincide, verás **OK ✅**. Si no, **MISMATCH ❌**.

> Coloca tu PDF en `codex/SHA-713_Codex.pdf` y mantén actualizado `hashes.txt`.

---

## 🤖 CI • GitHub Actions

Cada push ejecuta un workflow que recalcula SHA-256 y **falla si cambia 1 bit**.

Insignia (auto tras la primera corrida):  
`![Audit](https://github.com/gkfsupra/sha713-codex/actions/workflows/audit.yml/badge.svg)`

---

## 📄 Archivos clave
- `codex/` → coloca el PDF como `SHA-713_Codex.pdf`
- `hashes.txt` → lista de hashes esperados (ruta + sha256). Ejemplo:
  ```
  codex/SHA-713_Codex.pdf 7d8326c99521ba19e345367fda2456bc4a7a9f32c3108eb0a5dc8a9303f574bf
  ```
- `scripts/` → verificación local y utilidades QR
- `.github/workflows/audit.yml` → verificación automática
- `docs/` → página pública (GitHub Pages, opcional)

---

## 🧪 Actualizar el Códice
1. Reemplaza el PDF en `codex/SHA-713_Codex.pdf`.
2. Actualiza `hashes.txt` con el **nuevo SHA-256**.
3. Commit. CI lo verificará automáticamente.

Para calcular un hash localmente:
```bash
python3 scripts/verify_sha256.py --file "codex/SHA-713_Codex.pdf"
```

---

## 🔐 Seguridad
Lee **SECURITY.md** para reportar vulnerabilidades.

## 📜 Licencia
MIT — ver **LICENSE**.

— *GiankooF · MetaCreador · SHA-713*
