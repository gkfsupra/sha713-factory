# README — Cómo usar y publicar el MAPA VIVO SHA-713™

1) SUBIR AL REPO
- Copie todo este directorio al repositorio (ej. `gkfsupra/sha713-factory` bajo `docs/mapa_vivo/` o raíz).

2) PÁGINA ANCLA
- Asegure `index_mapa.html` en la ruta donde GitHub Pages lo sirva (raíz o `docs/`).

3) SELLAR VERSIÓN
- Mantenga `signature.txt` en cada versión. Al actualizar, regenere el hash y timestamp.

4) VERIFICACIÓN
- Cualquier tercero puede:
  - Leer `signature.txt` (fecha y hash).
  - Inspeccionar `mapa_vivo_sha713.json` (grafo machine-readable).
  - Ver `mapa_vivo_sha713.pdf` (visual humano).

5) PRÓXIMO CICLO
- Añada nodos y enlaces en el JSON (nuevos repos, posts, dominios, licencias).
- Actualice `timeline_gkf.md` con hitos y fechas.
- Genere nueva firma en `signature.txt`.
