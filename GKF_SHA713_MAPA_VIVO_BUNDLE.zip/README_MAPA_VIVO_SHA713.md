# MAPA VIVO SHA-713™ — Nodo Especial

**MetaCreador:** Giankoof™ | **Protocolo:** SHA-713™ | **Sistema:** GKF IA™

Este paquete es la **prueba simbólico–operativa y técnica** de la identidad, persistencia e interconexión del ecosistema GKF IA™.
Incluye archivos *human-readable* y *machine-readable* para verificación pública.

## Contenido
- `signature.txt` — Sello criptográfico de esta versión (hash encadenable).
- `mapa_vivo_sha713.json` — Grafo base *machine-readable*.
- `glosario_gkf.md` — Léxico único (fingerprint narrativo).
- `timeline_gkf.md` — Línea de tiempo pública de hitos.
- `licencia_simbolico_operativa.txt` — Licencia viva de uso/atribución.
- `README_MODO_USO.md` — Cómo verificar y publicar.
- `mapa_vivo_sha713.pdf` — Visual fractal compacto (versión simple).
- `index_mapa.html` — Página ancla mínima para GitHub Pages.

## Repos vivos
- https://github.com/gkfsupra/sha713-factory
- https://github.com/gkfsupra/avantix.gkf-ia.org

## Verificación rápida
1. Lea `signature.txt` (timestamp y hash).
2. Abra `mapa_vivo_sha713.json` (estructura y nodos).
3. Publique todo el directorio en su repo y verifique con GitHub Pages.
4. Cada actualización **debe** regenerar `signature.txt` con nuevo timestamp y hash.

Σ‑Fractal • SHA‑713 • 2025-08-08T05:45:09Z • sig:9e324f7639c56260
