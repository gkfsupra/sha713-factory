All Rights Reserved © Giankoof — GKF IA™. 
This repository contains proprietary symbolic-operational materials. Do not copy or redistribute without written permission.
