# Security Policy

- Rotate `SHA713_KEY` every 90 days.
- Protect `main` with required checks and signed commits.
- Report any vulnerability via private channel.
