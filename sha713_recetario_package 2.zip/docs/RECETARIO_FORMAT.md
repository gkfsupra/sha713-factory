# RECETARIO Format

Each recipe is a Markdown file with front-matter:

```yaml
---
id: "unique-id"
mu:
  culture: "Nexus SUPRA"
  strategy: "SHA-713 Seed"
  time: "YYYY-MM-DDTHH:MM:SSZ"
confidential: false
tags: [recetario, sha713]
hash: ""          # computed by tool
x_sha713_sig: ""  # computed by tool
---
```

- `confidential: true` excludes it from embeddings and bundles meant for public use.
