import os, sys, json, hmac, hashlib, urllib.request, argparse

def hmac_sig(key: str, body: bytes) -> str:
    return hmac.new(key.encode(), body, hashlib.sha256).hexdigest()

p = argparse.ArgumentParser()
p.add_argument("--webhook", required=True)
p.add_argument("--key", required=True)
p.add_argument("--repo", required=True)
p.add_argument("--commit", required=True)
p.add_argument("--index-url", required=True)
a = p.parse_args()

payload = {
  "event": "sha713.index",
  "repo": a.repo,
  "commit": a.commit,
  "recetario_index_url": a.index_url
}
body = json.dumps(payload).encode("utf-8")
sig = hmac_sig(a.key, body)

req = urllib.request.Request(
    a.webhook,
    data=body,
    headers={"Content-Type":"application/json", "X-SHA713-Signature": sig}
)

with urllib.request.urlopen(req) as r:
    print(r.read().decode())
