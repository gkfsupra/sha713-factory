import os, argparse, glob, json, hashlib, hmac, frontmatter, zipfile
from pathlib import Path

def sign_text(key: str, text: str) -> str:
    return hmac.new(key.encode(), text.encode(), hashlib.sha256).hexdigest()

def sha256(text: str) -> str:
    return hashlib.sha256(text.encode()).hexdigest()

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--src", required=True)
    p.add_argument("--out", required=True)
    p.add_argument("--bundle", required=True)
    args = p.parse_args()

    key = os.getenv("SHA713_KEY", "DEV-KEY")
    src = Path(args.src)
    items = []
    for pth in glob.glob(str(src / "*.md")):
        post = frontmatter.load(pth)
        content = post.content.strip()
        digest = sha256(content)
        sig = sign_text(key, content)

        # update fields in memory (do not overwrite on disk)
        meta = dict(post.metadata)
        meta["hash"] = digest
        meta["x_sha713_sig"] = sig

        items.append({
            "id": meta.get("id") or Path(pth).stem,
            "meta": meta,
            "path": str(Path(pth).name)
        })

    index = {
        "spec": "sha713-index/1.0",
        "count": len(items),
        "items": items
    }
    with open(args.out, "w", encoding="utf-8") as f:
        json.dump(index, f, ensure_ascii=False, indent=2)

    # Bundle
    with zipfile.ZipFile(args.bundle, "w", compression=zipfile.ZIP_DEFLATED) as z:
        z.write(args.out, arcname="recetario-index.json")
        for pth in glob.glob(str(src / "*.md")):
            z.write(pth, arcname=f"RECETARIO/{Path(pth).name}")
    print(f"[sha713] wrote {args.out} and {args.bundle} ({len(items)} items)")

if __name__ == "__main__":
    main()
