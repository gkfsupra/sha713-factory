import json, glob, frontmatter, hashlib, argparse
from pathlib import Path

p=argparse.ArgumentParser()
p.add_argument("--src",required=True)
p.add_argument("--out",required=True)
a=p.parse_args()

rows=[]
for pth in glob.glob(str(Path(a.src)/"*.md")):
    post = frontmatter.load(pth)
    text = post.content.strip()
    mid  = post.get("id") or hashlib.sha256(text.encode()).hexdigest()[:12]
    meta = dict(post.metadata)
    if meta.get("confidential", False):
        continue
    rows.append({"id": mid, "text": text, "meta": meta})

with open(a.out,"w",encoding="utf-8") as f:
    for r in rows:
        f.write(json.dumps(r,ensure_ascii=False)+"\n")
print(f"[sha713] wrote {len(rows)} rows → {a.out}")
