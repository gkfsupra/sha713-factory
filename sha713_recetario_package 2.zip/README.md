# Recetario del Futuro — SHA-713™

This repository contains the bilingual **Recetario del Futuro** and an **autonomous pipeline** to:
- compute SHA-256 digests,
- attach HMAC signatures (SHA-713 secret),
- build an index + bundle,
- (optionally) push embeddings, and
- notify Codex via signed webhook.

## Quick Start
1) Add Secrets in GitHub → Settings → Secrets → Actions
   - `SHA713_KEY` (required) — long random key
   - `CODEX_WEBHOOK` (optional) — your endpoint to receive index notifications
   - `EMBEDDINGS_API_URL` / `EMBEDDINGS_API_KEY` (optional)
2) Commit any recipe under `RECETARIO/`
3) The workflow `.github/workflows/sha713_index.yml` will run and publish:
   - `recetario-index.json`
   - `sha713-artifacts.zip`

## Notes
- The signature included in each recipe at commit time is a **demo** and will be recomputed by the workflow using your secret.
- Mark sensitive entries with `confidential: true` to exclude from public embeddings.
