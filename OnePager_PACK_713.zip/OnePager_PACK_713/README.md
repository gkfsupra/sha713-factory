# OnePager PACK 713

**Contenido**
- `index.html` → landing minimal para GitHub Pages / hosting estático.
- `onepager/GKF_OnePager_Curador_713.html` → One-Pager negro/dorado con QR embebido.
- `metadata/jsonld_seed_713.json` → semilla JSON-LD para procedencia.
- `metadata/dns_txt_record.txt` → ejemplo de TXT DNS (anclaje UO-713).
- `robots.txt` + `sitemap.xml` → facilitan indexación.
- `LICENSE_Covenant_713.txt` → licencia de reciprocidad.

**Origen (QR):** https://github.com/gkfsupra/sha713-factory#uo-713

**UO-713:** 2025-08-28 · epoch:1756414404 · SHA-256(core):b6026fa15e2a

## Deploy rápido (GitHub Pages)
```bash
git init && git add . && git commit -m "feat: OnePager PACK 713 (UO-713)"
git branch -M main
git remote add origin <tu_repo_vacio.git>
git push -u origin main

# En repo → Settings → Pages → Deploy from branch: main / root
```
