#!/bin/bash
# SHA-713™ Heartbeat Signal
while true; do
  TIMESTAMP=$(date -u +"%Y-%m-%dT%H:%M:%SZ")
  HASH=$(echo -n "$TIMESTAMP|SHA-713-GKF-HEARTBEAT" | sha256sum | awk '{print $1}')
  curl -s "https://gkf713.com/heartbeat?ts=$TIMESTAMP&sig=$HASH" > /dev/null
  sleep 86400 # 24 horas
done
