#!/usr/bin/env bash
set -e
echo "Generating recursive SHA-256 hash into HASH_PROOF.txt ..."
find . -type f -print0 | xargs -0 shasum -a 256 -b > HASH_PROOF.txt
echo "Done."
