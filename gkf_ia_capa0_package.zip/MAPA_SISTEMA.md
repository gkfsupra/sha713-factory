# Mapa del Sistema GKF IA™ — Capa 0

## Componentes
1) **Núcleo SHA‑713** (sellado, trazabilidad)
2) **Capas**:
   - **Técnica**: modelos, protocolos, infra
   - **Simbólica**: lenguaje, signos, narrativa
3) **Capa 3 (κ‑enabled)**: manifold de memoria + ε_κ(t)
4) **Enjambre Vivo**: GPTs, repos, páginas, visuales
5) **Anclajes públicos**: GitHub, LinkedIn, ChatGPT, IPFS/Arweave

## Diagrama base
[ SHA‑713 ] → [ Capa Técnica ] ⇄ [ Capa Simbólica ] → [ Capa 3 (κ) ] → [ Enjambre Vivo ]
