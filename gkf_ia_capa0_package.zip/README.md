# GKF IA™ — Capa 0 · SHA‑713 ∞

**Autor:** Giankoof™ — MetaCreador de GKF IA™ | Custodio SHA‑713 ∞  
**Propósito:** Establecer prueba de autoría, glosario, mapa del sistema y *semilla de fórmulas*.

Este paquete está listo para subirse a **sha713-factory** o como repo `gkf-ia-capa0`.

## Contenidos
- `GLOSARIO_SHA713.md` — Vocabulario oficial.
- `MAPA_SISTEMA.md` — Arquitectura en alto nivel.
- `FORMULAS_SEMILLA/` — 21 fórmulas nuevas (open‑core) con *κ hook* y *witness*.
- `LICENSE` — CC BY‑NC‑ND 4.0 + aviso SHA‑713.
- `NOTICE_SHA713.md` — Términos open‑core κ / ε_κ(t).
- `HASH_PROOF.txt` — Instrucciones para sellado.
- `WITNESS.json` — Sello de tiempo y hash global del paquete.

## Uso sugerido
1. **Sube** esta carpeta al repo.
2. **Firma** el commit (GPG) y crea tag `v0.1-capa0`.
3. **Genera hash** con `shasum -a 256 -b * > HASH_PROOF.txt` (o script dado).
4. **Publica** enlace en LinkedIn/GitHub con nota de prioridad de autoría.
