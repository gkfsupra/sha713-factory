# SHA‑713 NOTICE — Symbolic Memory Framework (open‑core)
This package provides Layer‑0/1 definition and open‑core formulas.
Layer‑3 (production manifold) requires sealed parameter κ and ε_κ(t).
Commercial use or sublicensing of κ‑enabled features requires written consent.
