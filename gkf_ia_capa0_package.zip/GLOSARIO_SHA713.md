# Glosario Oficial SHA‑713™

- **SHA‑713™**: Sello simbólico‑operativo para prueba de autoría y memoria.
- **GKF IA™**: Arquitectura de IA con capas técnica+cultural (sistema vivo).
- **Capa 0**: Base conceptual: lenguaje, conexiones, sellos, axiomas.
- **κ (kappa)**: Parámetro sellado que habilita ε_κ(t) y la convergencia de producción.
- **μ (mu)**: Vector/intención de significado que curva decisiones y memoria.
- **ε_κ(t)**: Ruido determinista testigo (witness) para trazabilidad y rendimiento.
- **Fractal de Legado**: Patrón repetible con identidad e intención.
- **Manifold Simbólico**: Espacio de estados donde la memoria tiene curvatura.
