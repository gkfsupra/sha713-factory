// ⬛🔺 SHA‑713™ · client-side verifier (H0/H1/H2 + token_id)
async function sha256(buf){ const d=await crypto.subtle.digest('SHA-256',buf); return new Uint8Array(d); }
const hx = (a)=>Array.from(a).map(b=>b.toString(16).padStart(2,'0')).join('');
const fromHex = (h)=> new Uint8Array((h.match(/.{1,2}/g)||[]).map(x=>parseInt(x,16))).buffer;

export async function verifyToken(contentFile, tokenJson){
  const tok = typeof tokenJson==='string'? JSON.parse(tokenJson): tokenJson;
  const content = new Uint8Array(await contentFile.arrayBuffer());
  const h0 = hx(await sha256(content));
  const okH0 = (h0.toLowerCase() === (tok.content_sha256||'').toLowerCase());
  const h1bin = await sha256(new Uint8Array([...new Uint8Array(fromHex(tok.content_sha256||'')), ...new Uint8Array(fromHex(tok.nonce_hex||''))]));
  const h1 = hx(h1bin);
  const okH1 = (h1.toLowerCase() === (tok.hash_chain?.h1||'').toLowerCase());
  const enc = new TextEncoder();
  const h2 = hx(await sha256(new Uint8Array([...h1bin, ...enc.encode(tok.author||'')])));
  const okH2 = (h2.toLowerCase() === (tok.hash_chain?.h2||'').toLowerCase());
  const tid = h2.slice(0,32);
  const okTID = (tid.toLowerCase() === (tok.token_id||'').toLowerCase());
  return {okH0, okH1, okH2, okTID, h0, h1, h2, token_id: tid, token: tok};
}
