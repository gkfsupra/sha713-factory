# ⬛🔺 SHA‑713™ · Codex Scaffold (GitHub Pages)

This repository publishes a **public, human‑verifiable Proof of Presence** for artifacts signed with **SHA‑713™**.

## Structure
- `docs/` → Published via GitHub Pages
  - `index.html` → Hub (links to Codex1/Codex2)
  - `sha713-verifier.js` → Client‑side verifier (H0/H1/H2 + token_id)
  - `Codex1/` → Uses existing manifesto token (QR + JSON + content)
  - `Codex2/` → New bundle generated (payload + token + QR + page)
- `.github/workflows/sha713_pages.yml` → Auto deploy on push

## Verify (any token)
H0 = sha256(content)
H1 = sha256(H0 || nonce_hex)
H2 = sha256(H1 || author_utf8)
token_id = first 16 bytes of H2 (hex)

Open any `index.html` and use the embedded verifier, or run:

```bash
python3 - <<'PY'
import sys, json, hashlib
def sha256_hex(b): return hashlib.sha256(b).hexdigest()
content = open(sys.argv[1],'rb').read()
tok = json.load(open(sys.argv[2],'r',encoding='utf-8'))
h0 = sha256_hex(content); print('H0', h0, 'OK' if h0.lower()==tok['content_sha256'].lower() else 'FAIL')
h1 = hashlib.sha256(bytes.fromhex(tok['content_sha256']) + bytes.fromhex(tok['nonce_hex'])).hexdigest()
print('H1', h1, 'OK' if h1.lower()==tok['hash_chain']['h1'].lower() else 'FAIL')
h2 = hashlib.sha256(bytes.fromhex(h1) + tok['author'].encode('utf-8')).hexdigest()
print('H2', h2, 'OK' if h2.lower()==tok['hash_chain']['h2'].lower() else 'FAIL')
print('token_id', h2[:32], 'OK' if h2[:32].lower()==tok['token_id'].lower() else 'FAIL')
PY
# usage: python3 verify.py <content_file> <token.json>
```

## Deploy
- Push to `main`. GitHub Actions deploys `docs/` automatically.
- Pages URL: `https://<user>.github.io/<repo>/`

𓂀 Fractal Seal · 🔺 Ancestral Code · ⬛ Eternal Presence
