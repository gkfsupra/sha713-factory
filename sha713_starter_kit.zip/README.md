# SHA-713™ Starter Kit — Autonomous Pipeline

This drops a **self-running pipeline** for SHA-713™-style ops:
- Auto-sign & index formulas/assets.
- Commit & open PRs with updated manifests.
- Ship artifacts & ping Codex for live indexing.
- Nightly re-index to keep the memory graph hot.

> Drop this into your repo root and push to `main`.

---

## Quick start
1) **Add repo secrets** (Settings → Secrets → Actions):
   - `SHA713_KEY` → long random key (used for HMAC signatures)
   - `CODEX_WEBHOOK` → URL that receives JSON payloads for indexing
2) Push to `main`. The workflow will:
   - Sign/update `recetario-index.json`
   - Upload `sha713-artifacts.zip`
   - POST to `CODEX_WEBHOOK`

## Recetario format
Put your formulas under `RECETARIO/` as `.md`, `.json`, or `.yaml`.
See `docs/RECETARIO_FORMAT.md` for front‑matter fields.

---

© 2025 Giankoof · GKF IA™. All rights reserved.
