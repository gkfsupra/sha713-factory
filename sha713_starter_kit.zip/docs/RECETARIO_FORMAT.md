# Recetario Format (SHA-713™)

Each formula can be `.md`, `.yaml`, or `.json` and may include optional front‑matter:

```yaml
---
id: "FORMULA-0001"
title: "Symbolic Memory Update: μ-anchored Q"
mu_tags: ["culture:maya", "strategy:brand", "time:seasonal"]
version: "1.0.0"
confidential: true
---
```

Body can contain **pseudocode**, **math**, and **execution hints**. The indexer will extract:
- `id`, `title`, `version`, `mu_tags`
- SHA-256 digest, size, modified time
- Optional `confidential` flag (excluded from webhook payload)
