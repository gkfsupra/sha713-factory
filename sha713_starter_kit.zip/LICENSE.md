All Rights Reserved — GKF IA™ / SHA-713™

You may view the repository and run the provided workflows within this repo.
Any reuse, distribution, commercial use, or derivative work **requires prior written consent**.

For partnership/licensing: licensing@gkf-ia.org
