# Security Policy

- Report sensitive issues via: security@gkf-ia.org
- Please **do not** open public issues for vulnerabilities.
- Include commit hashes and minimal repro when possible.

The pipeline signs artifacts with HMAC (`SHA713_KEY`) and
records immutable digests in `recetario-index.json`.
