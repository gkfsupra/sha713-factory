#!/usr/bin/env python3
import os, sys, json, time, hashlib, hmac, base64, pathlib, datetime

ROOT = pathlib.Path(__file__).resolve().parents[1]
RECETARIO = ROOT / "RECETARIO"
INDEX = ROOT / "recetario-index.json"
KEY = os.environ.get("SHA713_KEY", "")

def sha256_file(p: pathlib.Path) -> str:
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            h.update(chunk)
    return h.hexdigest()

def parse_front_matter(text: str):
    if text.startswith("---"):
        try:
            end = text.find("\n---", 3)
            if end != -1:
                fm = text[3:end].strip()
                body = text[end+4:]
                # naive YAML-ish parse
                meta = {}
                for line in fm.splitlines():
                    if ":" in line:
                        k, v = line.split(":", 1)
                        meta[k.strip()] = v.strip().strip('"').strip("'")
                return meta, body
        except Exception:
            pass
    return {}, text

def collect():
    items = []
    if not RECETARIO.exists():
        return items
    for p in RECETARIO.rglob("*"):
        if p.is_file():
            ext = p.suffix.lower()
            if ext in [".md", ".json", ".yaml", ".yml"]:
                meta = {}
                if ext == ".md":
                    try:
                        meta, _ = parse_front_matter(p.read_text(encoding="utf-8", errors="ignore"))
                    except Exception:
                        meta = {}
                stat = p.stat()
                items.append({
                    "path": str(p.relative_to(ROOT)),
                    "sha256": sha256_file(p),
                    "size": stat.st_size,
                    "mtime": int(stat.st_mtime),
                    "meta": meta,
                })
    return items

def sign(payload: bytes) -> str:
    if not KEY:
        return ""
    mac = hmac.new(KEY.encode("utf-8"), payload, hashlib.sha256).digest()
    return base64.b64encode(mac).decode("ascii")

def main():
    items = collect()
    now = int(time.time())
    doc = {
        "schema": "sha713.recetario.index/1-0",
        "generated_at": now,
        "items": items,
    }
    raw = json.dumps(doc, ensure_ascii=False, separators=(",",":")).encode("utf-8")
    sig = sign(raw)
    out = {
        "doc": doc,
        "signature": sig,
    }
    INDEX.write_text(json.dumps(out, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"Wrote {INDEX} with {len(items)} items")
    # produce artifacts bundle
    import zipfile
    art = ROOT / "sha713-artifacts.zip"
    with zipfile.ZipFile(art, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("RECETARIO_README.txt", "Bundle of current formulas.")
        z.write(INDEX, INDEX.name)
        for it in items:
            z.write(ROOT / it["path"], it["path"])
    print(f"Bundled {art}")

if __name__ == "__main__":
    main()
