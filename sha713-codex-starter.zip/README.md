# SHA-713 Codex — Public Audit

**Artifact:** `SHA-713_Codex_Giankoof.pdf`  
**SHA-256:** `7d8326c99521ba19e345367fda2456bc4a7a9f32c3108eb0a5dc8a9303f574bf`

## Verify locally
**macOS / Linux**
```bash
shasum -a 256 SHA-713_Codex_Giankoof.pdf
```

**Windows (PowerShell)**
```powershell
certutil -hashfile "SHA-713_Codex_Giankoof.pdf" SHA256
```

## Why SHA-713?
Auditability > speed. This repo holds the codex, hashes, and QR to verify provenance.

## Files
- `SHA-713_Codex_Giankoof.pdf` — the codex (black/gold edition)
- `hashes.txt` — list of SHA-256 hashes for artifacts
- `proof/manifest.json` — provenance metadata
- `qr_repo.png` — QR to intended repo URL (optional)
- `qr_profile.png` — QR to profile https://github.com/gkfsupra (fallback)
