# Security Policy

## Supported Versions
- main

## Reporting a Vulnerability
Si encuentras una vulnerabilidad o riesgo en este repositorio, abre un **Security advisory** privado o escribe a: security@gkf-ia.org (placeholder).

No envíes secretos ni datos personales en issues públicas.
