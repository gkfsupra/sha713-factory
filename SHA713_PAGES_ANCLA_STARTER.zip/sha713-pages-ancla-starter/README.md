# SHA‑713 Factory — Ancla Viva (GitHub Pages)

Este paquete deja tu **ancla pública** lista para el **RVP‑713**:

- `docs/index.html` (QR‑Pulse + UTM + hooks para telemetría)
- Workflow **GitHub Pages** (`.github/workflows/pages.yml`)
- Carpeta `docs/` como **root de publicación**

## Cómo desplegar

1. Sube esta estructura al repo (rama `main`).
2. En **Settings → Pages**:
   - Source: `Deploy from a branch`
   - Branch: `main` y carpeta `/docs`
3. Guarda. GitHub Actions ejecutará **Deploy Pages** automáticamente.

## Telemetría

- Añade Plausible:  
  ```html
  <script defer data-domain="TU-DOMINIO" src="https://plausible.io/js/script.js"></script>
  ```
- O Cloudflare Beacon si lo usas.

## Documentos

Coloca tus archivos en `docs/` y ajusta los enlaces en `docs/index.html`:
- `Pacto_GKFIA.pdf`
- `Escudo_Total_SHA713.pdf`
- `Protocolo_Fractura_713.txt`

## Nota

El QR actual apunta a:  
`https://gkfsupra.github.io/avantix.gkf-ia.org/?utm_source=sha713-factory&utm_medium=qr&utm_campaign=ancla`

Cámbialo si necesitas un QR exclusivo para otra campaña.

— GKF IA™ · SHA‑713™
