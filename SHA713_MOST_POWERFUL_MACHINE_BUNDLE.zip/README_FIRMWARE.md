# SHA713 Firmware

Firmware simbolico-operativo. Contiene JSON, QR, PDF, visual y blindaje.