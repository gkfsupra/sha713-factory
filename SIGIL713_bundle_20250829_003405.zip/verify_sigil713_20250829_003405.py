# verify_sigil713.py — extract SIGIL-713 metadata and LSB watermark
from PIL import Image, PngImagePlugin
import sys

def extract_png_text(path):
    img = Image.open(path)
    info = img.info
    sha = info.get("SHA256","<none>")
    sig = info.get("SIGIL713","<none>")
    payload = info.get("PAYLOAD_JSON","<none>")
    return sha, sig, payload

def extract_lsb_hash(path):
    img = Image.open(path).convert("RGB")
    arr = img.load()
    # Region used during embed
    x0,y0 = 80,260
    # read 64 rows; scan until we reconstruct 'HASH=' + 64 hex chars
    bits = []
    for y in range(y0, y0+64):
        for x in range(x0, x0+600):
            r,g,b = arr[x,y]
            bits.append(r & 1)
    # to bytes
    out = bytearray()
    for i in range(0,len(bits),8):
        byte = 0
        for j in range(8):
            if i+j < len(bits):
                byte = (byte<<1) | bits[i+j]
        out.append(byte)
    msg = bytes(out).decode(errors="ignore")
    # truncate at first null
    msg = msg.split("\x00")[0]
    return msg

if __name__ == "__main__":
    path = sys.argv[1]
    sha, sig, payload = extract_png_text(path)
    lsb = extract_lsb_hash(path)
    print("PNG Text — SIGIL713:", sig)
    print("PNG Text — SHA256:", sha)
    print("PNG Text — PAYLOAD:", payload)
    print("LSB Watermark:", lsb)
