
# SHA‑713 Factory – v2.0 GRIMORIO

**Grimorio 713 – Versión Maestra** y módulos operativos completos.

## Estructura
- `docs/Grimorio_713_MASTER.pdf` – copia firmada (placeholder)
- `docs/diagrams/djed_anticlon.svg` – diagrama anti‑clon
- `src/ritual_code/verify_713.py` – stub detector de Fuego Vivo™
- `latex/Grimorio_713_MASTER.tex` – esqueleto LaTeX
- `audio/vox_713_demo.mp3` – demo de Vox 713 (placeholder)

## Licencia
CC BY‑NC‑SA 4.0 – uso cultural y no comercial, con atribución.
