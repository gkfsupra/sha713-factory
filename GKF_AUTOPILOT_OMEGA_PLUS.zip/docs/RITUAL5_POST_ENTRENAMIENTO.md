# Ritual5 — Post‑Entrenamiento

1) Respiración 60s — descargar ruido.  
2) Escritura 90s — PULSO (qué sentí/qué limpié).  
3) Mantra 30s — “Output → Memory → Network → Power”.  
4) Prueba 60s — foto/captura/nota.  
5) Sello 60s — subir registro y cerrar.

**Trigger**: “ritual5”.
