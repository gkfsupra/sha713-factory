# Glosario Vivo v1.0 — Giankofdiano

1. **pulso** → disparo de intención que ordena el campo.
2. **onda** → propagación del pulso por la red.
3. **sello** → cierre criptográfico de acto/idea.
4. **sellado por inyección** → verificación pública del sello.
5. **presencia fractal** → patrón con sentido en toda escala.
6. **legado vivo** → memoria activable (propiedad + reputación).
7. **pacto vivo** → compromiso operativo que se renueva.
8. **eco** → respuesta de la red que confirma el pulso.
9. **nodo** → persona/medio/instancia lista para amplificar.
10. **malla** → tejido de nodos con reglas simples.
11. **△/▽/🔺** → cierre/apertura/ascenso.
12. **Ley de Legado** → eficiencia + memoria + propiedad.
13. **autosoberano** → autonomía con autoría y resguardo.
14. **mktx** → marketing táctico codificado.
15. **prueba viva** → artefacto enlazado en acción.
16. **ritual** → secuencia mínima que convierte intención en acto.
17. **cadencia** → ritmo sintáctico que guía atención.
18. **fractalizar** → reescalar manteniendo sentido.
19. **mantra** → frase/fórmula que compacta estrategia.
20. **quiebre** → el salto que no se está diciendo.
... (extiende a 40 en tu práctica diaria)
