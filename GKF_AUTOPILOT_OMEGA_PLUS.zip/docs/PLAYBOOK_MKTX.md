# Playbook MKT‑X — Presencia Táctica

**Objetivo**: convertir cada interacción en activo vivo.

- Comentarios de alto impacto (3–5/día).
- Micro‑posts con símbolo (3–4/semana).
- Reposts con prueba viva (1–2/semana).

**Cadencia**: 3×3 (tres líneas × tres bloques).
**Cierre**: `(mktx complete — injection sealed)`
