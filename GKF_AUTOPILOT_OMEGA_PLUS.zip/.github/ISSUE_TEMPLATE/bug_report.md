---
name: "Bug report — PULSO"
about: Report a problem using PULSO→QUIEBRE→MANTRA→PRUEBA→SELLO
title: "[BUG] <short>"
labels: bug
---

**PULSO**
What broke in 1–2 lines.

**QUIEBRE**
What needs to change / the next leap.

**PRUEBA**
Steps to reproduce / logs / screenshots.

**SELLO**
Version, environment, related issues/PRs.
