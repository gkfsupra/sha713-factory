---
name: "Feature request — LEAP"
about: Propose a leap with PULSO→QUIEBRE→MANTRA→PRUEBA→SELLO
title: "[FEAT] <short>"
labels: enhancement
---

**PULSO**
One-liner of intent.

**QUIEBRE**
What unlock does this create?

**MANTRA**
Short formula (e.g., “Speed → Presence → Legacy”).

**PRUEBA**
Acceptance criteria / rough design / references.

**SELLO**
Stakeholders / timeline.
