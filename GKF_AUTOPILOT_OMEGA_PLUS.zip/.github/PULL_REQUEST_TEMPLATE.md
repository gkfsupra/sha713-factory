# PR — (injection sealed)

**PULSO**
What this PR does in one or two lines.

**QUIEBRE**
What leap it enables.

**PRUEBA**
Tests / screenshots / docs.

**SELLO**
Linked issues / checklist.
- [ ] Lints pass
- [ ] Tests pass
