# Security Policy

- Report vulnerabilities via private issue or security email.
- Do not open public issues with exploit details.
- We follow responsible disclosure and will credit contributors.

**Principle**: *Protect legacy > chase speed.*
