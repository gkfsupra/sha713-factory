# acquirer stub
