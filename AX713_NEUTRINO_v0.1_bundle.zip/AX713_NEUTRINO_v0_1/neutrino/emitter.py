# emitter stub
