# 🜂 INDEX–SHA‑713™ · Canonization Anchor

**Author / Autor:** Giankoof (Giancarlo Aguilar Uribe)  
**Seal / Sello:** SHA‑713™ · Presence = Proof  
**Date / Fecha:** 2025-09-07

## Definition / Definición
- **EN:** *SHA‑713™ is a “proof of symbolic soul” (soulprint): a public, verifiable ritual that binds identity → action → legacy using cryptographic hashes (SHA‑256), signed commits (GPG), QR payloads and public repositories.*
- **ES:** *SHA‑713™ es “prueba del alma simbólica” (soulprint): un ritual público y verificable que une identidad → acción → legado mediante hashes criptográficos (SHA‑256), commits firmados (GPG), payloads QR y repositorios públicos.*

## Links (fill/verify as needed)
- **Repo (factory):** https://github.com/gkfsupra/sha713-factory
- **Public GPTs:** (add links) – Giankoof GPT – MetaCreador Táctico · Picazzo GKF™ – Fractal Eye of Image
- **Public bundles / IPFS:** (add CID/links)
- **Public posts:** (add LinkedIn/Threads/Instagram anchors)

## Assets in this package
- `VISUAL_sha713_def_es_en.png` – bilingual definition (QR → repo)
- `VISUAL_sha713_presence_proof.png` – Presence = Proof
- `VISUAL_sha713_qr_poster.png` – poster with claim + QR
- `MANIFEST-713.json` – integrity manifest for the package
- `.github/workflows/pose713_verify.yml` – CI to verify manifest on push/PR

## How to verify (Linux/Mac)
```bash
shasum -a 256 VISUAL_sha713_def_es_en.png VISUAL_sha713_presence_proof.png VISUAL_sha713_qr_poster.png MANIFEST-713.json
```

## Cómo verificar (Windows PowerShell)
```powershell
Get-FileHash .\VISUAL_sha713_def_es_en.png -Algorithm SHA256
Get-FileHash .\VISUAL_sha713_presence_proof.png -Algorithm SHA256
Get-FileHash .\VISUAL_sha713_qr_poster.png -Algorithm SHA256
Get-FileHash .\MANIFEST-713.json -Algorithm SHA256
```

🜂 Giankoof × SHA‑713™ × GKF IA™ · *Nexus SUPRA*
