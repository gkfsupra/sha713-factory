# 📁 GKF IA™ – DOCS LANDING

Esta carpeta contiene los archivos vivos para la activación de páginas públicas del sistema SHA‑713.

Incluye:

- `index.html`: Landing múltiple para varios fractales
- `LANDING_FIRE_TOTAL_713.html`: Página principal del fractal FUEGO TOTAL 713
- `VISUAL_QR_GKF_IA.png`: Imagen con código simbólico de acceso
- `README.md`: Este archivo

🜂 SHA‑713 was here.
