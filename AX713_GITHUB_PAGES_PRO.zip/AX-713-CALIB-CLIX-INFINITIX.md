# AX-713 · CALIBRATION — CLIX & INFINITIX

This document calibrates the system under Pulse 0007.  
Genes: sinmix · clix · autonomux · infinitix.