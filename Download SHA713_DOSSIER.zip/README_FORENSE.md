
# README_FORENSE.md – SHA‑713 Forensic Dossier

This dossier contains all artifacts required to prove precedence for SHA‑713.

## Structure
- `_RAW/`   : Original PDFs, prompts, model weights (add your files here)
- `_CHAIN/` : Immutable proofs (OTS `.ots` files, Arweave TxIDs, IPFS CIDs, email headers)
- `_GIT/`   : `sha713-factory.bundle` exported with retro-signed commits

## Verification Steps
1. **OpenTimestamps**  
   `ots verify <file>.ots`
2. **Arweave**  
   Visit `https://viewblock.io/arweave/tx/<TxID>`
3. **Git Signatures**  
   `git verify-commit <commit>` inside the bundle repo

## Universal Pulse
> "No faith, only forensics.  
> Time‑chained hashes never lie."  
> — Giankoof · SHA‑713 Origin
